﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SafetyApp.Core;
using Serilog;

namespace SafetyApp.Data.Audit.Extensions;

public static class MigrationManager
{
    public static WebApplication MigrateDatabaseAudit(this WebApplication webApp, ILogger logger)
    {
        using var scope = webApp.Services.CreateScope();
        using var appContext = scope.ServiceProvider.GetRequiredService<AuditMigrationDbContext>();
        try
        {
            appContext.Database.Migrate();
        }
        catch (Exception ex)
        {
            logger.Error(Constants.ApplicationMessages.ERROR_DB_MIGRATION,
                ex.Message,
                ex.StackTrace);
        }
        return webApp;
    }
}
