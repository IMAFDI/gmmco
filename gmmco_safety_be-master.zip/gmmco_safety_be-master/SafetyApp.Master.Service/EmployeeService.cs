﻿using ClosedXML.Excel;
using SafetyApp.Master.Data;
using SafetyApp.Master.Data.Interface;
using SafetyApp.Master.Service.Interface;

namespace SafetyApp.Master.Service;

public class EmployeeService : IEmployeeService
{
    private readonly IMasterUnitOfWork<MasterDbContext> _unitOfwork;

    public EmployeeService(
        IMasterUnitOfWork<MasterDbContext> unitOfwork
        )
    {
        if (unitOfwork != null)
        {
            _unitOfwork = unitOfwork;
        }
    }

    public async Task IngestEmployeesAsync(IEnumerable<EN_MSTR_Employee> employees, CancellationToken ct = default)
    {
        await _unitOfwork.EmployeeRepository.InsertOrIgnoreAsync(employees, ct);
    }

    public async Task<List<EN_MSTR_Employee>> GetAllEmployeesAsync(CancellationToken ct = default)
    {
        return await _unitOfwork.EmployeeRepository.GetAllEmployeesAsync(ct);
    }

    public async Task<EN_MSTR_Employee[]> GetEmployeesAsync(CancellationToken ct = default)
    {
        return await _unitOfwork.EmployeeRepository.FetchEmployeesAsync(ct);
    }

    public byte[] ExportToExcel(List<EN_MSTR_Employee> employees)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Employees");

        // Headers
        string[] headers = new[]
        {
            "Employee ID","First Name","Last Name","Date of Joining","Contribution Level",
            "Direct Manager","Manager Email","Manager Emp ID","Division","Sub Employee Type",
            "Employee Status","Employee Type","Job Level","PS Group","PS Level","SBU",
            "Date of Birth","Company Email","Gender","Office City","Office Location",
            "Office Region","Office State","Office Mobile","GMMCO Dept","Safety Role","Record Source"
        };

        for (int j = 0; j < headers.Length; j++)
            worksheet.Cell(1, j + 1).Value = headers[j];

        // Data
        for (int i = 0; i < employees.Count; i++)
        {
            var emp = employees[i];
            worksheet.Cell(i + 2, 1).Value = emp.EmployeeId;
            worksheet.Cell(i + 2, 2).Value = emp.FirstName;
            worksheet.Cell(i + 2, 3).Value = emp.LastName;
            worksheet.Cell(i + 2, 4).Value = emp.DateOfJoining.ToString("dd-MM-yyyy");
            worksheet.Cell(i + 2, 5).Value = emp.ContributionLevel;
            worksheet.Cell(i + 2, 6).Value = emp.DirectManager;
            worksheet.Cell(i + 2, 7).Value = emp.DirectManagerEmail;
            worksheet.Cell(i + 2, 8).Value = emp.DirectManagerEmployeeId;
            worksheet.Cell(i + 2, 9).Value = emp.Division;
            worksheet.Cell(i + 2, 10).Value = emp.SubEmployeeType;
            worksheet.Cell(i + 2, 11).Value = emp.EmployeeStatus;
            worksheet.Cell(i + 2, 12).Value = emp.EmployeeType;
            worksheet.Cell(i + 2, 13).Value = emp.JobLevel;
            worksheet.Cell(i + 2, 14).Value = emp.PsGroup;
            worksheet.Cell(i + 2, 15).Value = emp.PsLevel;
            worksheet.Cell(i + 2, 16).Value = emp.SBU;
            worksheet.Cell(i + 2, 17).Value = emp.DateOfBirth.ToString("dd-MM-yyyy");
            worksheet.Cell(i + 2, 18).Value = emp.CompanyEmailId;
            worksheet.Cell(i + 2, 19).Value = emp.Gender;
            worksheet.Cell(i + 2, 20).Value = emp.OfficeCity;
            worksheet.Cell(i + 2, 21).Value = emp.OfficeLocation;
            worksheet.Cell(i + 2, 22).Value = emp.OfficeRegion;
            worksheet.Cell(i + 2, 23).Value = emp.OfficeState;
            worksheet.Cell(i + 2, 24).Value = emp.OfficeMobileNo;
            worksheet.Cell(i + 2, 25).Value = emp.GmmcoDept;
            worksheet.Cell(i + 2, 26).Value = emp.SafetyRole;
            worksheet.Cell(i + 2, 27).Value = emp.RECORD_SOURCE_NAME;
        }

        worksheet.Columns().AdjustToContents();

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }
}
