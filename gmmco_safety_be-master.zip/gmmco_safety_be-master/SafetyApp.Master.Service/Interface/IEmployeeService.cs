﻿namespace SafetyApp.Master.Service.Interface
{
    public interface IEmployeeService
    {
        Task IngestEmployeesAsync(IEnumerable<EN_MSTR_Employee> employees, CancellationToken ct = default);
        Task<List<EN_MSTR_Employee>> GetAllEmployeesAsync(CancellationToken ct = default);
        Task<EN_MSTR_Employee[]> GetEmployeesAsync(CancellationToken ct = default);
        byte[] ExportToExcel(List<EN_MSTR_Employee> employees);
    }
}