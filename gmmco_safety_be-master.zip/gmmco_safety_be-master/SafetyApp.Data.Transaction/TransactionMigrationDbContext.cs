﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SafetyApp.Core;
using SafetyApp.Transaction.Data;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Data.Transaction;

/// <summary>
/// Master Migration DB Context.
/// </summary>
[ExcludeFromCodeCoverage]
public class TransactionMigrationDbContext : TransactionDbContext
{
    private readonly IConfiguration _configuration;

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionMigrationDbContext"/> class.
    /// </summary>
    /// <remarks>
    /// See <see href="https://aka.ms/efcore-docs-dbcontext">DbContext lifetime, configuration, and initialization</see>
    /// for more information and examples.
    /// </remarks>
    public TransactionMigrationDbContext() { }

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionMigrationDbContext"/> class.
    /// </summary>
    /// <param name="configuration">The configuration.</param>
    public TransactionMigrationDbContext(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionMigrationDbContext" /> class.
    /// </summary>
    /// <param name="options">The options for this context.</param>
    /// <param name="configuration">The configuration.</param>
    /// <remarks>
    /// See <see href="https://aka.ms/efcore-docs-dbcontext">DbContext lifetime, configuration, and initialization</see> and
    /// <see href="https://aka.ms/efcore-docs-dbcontext-options">Using DbContextOptions</see> for more information and examples.
    /// </remarks>
    public TransactionMigrationDbContext(DbContextOptions<TransactionDbContext> options, IConfiguration configuration) : base(options)
    {
        _configuration = configuration;
    }

    /// <summary>
    /// Override this method to configure the database (and other options) to be used for this context.
    /// This method is called for each instance of the context that is created.
    /// The base implementation does nothing.
    /// </summary>
    /// <param name="optionsBuilder">A builder used to create or modify options for this context. Databases (and other extensions)
    /// typically define extension methods on this object that allow you to configure the context.</param>
    /// <remarks>
    /// <para>
    /// In situations where an instance of <see cref="T:Microsoft.EntityFrameworkCore.DbContextOptions" /> may or may not have been passed
    /// to the constructor, you can use <see cref="P:Microsoft.EntityFrameworkCore.DbContextOptionsBuilder.IsConfigured" /> to determine if
    /// the options have already been set, and skip some or all of the logic in
    /// <see cref="M:Microsoft.EntityFrameworkCore.DbContext.OnConfiguring(Microsoft.EntityFrameworkCore.DbContextOptionsBuilder)" />.
    /// </para>
    /// <para>
    /// See <see href="https://aka.ms/efcore-docs-dbcontext">DbContext lifetime, configuration, and initialization</see>
    /// for more information and examples.
    /// </para>
    /// </remarks>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql
        (
            _configuration.GetConnectionString(Constants.ConfigurationKeys.CONNECTION_STRING)
        );
    }
}
