﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SafetyApp.Core;
using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;
using Serilog;


namespace SafetyApp.Data.Transaction.Extensions;

public static class MigrationManager
{
    public static WebApplication MigrateDatabaseTransaction(this WebApplication webApp, ILogger logger)
    {
        using var scope = webApp.Services.CreateScope();
        using var appContext = scope.ServiceProvider.GetRequiredService<TransactionMigrationDbContext>();
        using var unitOfWork = scope.ServiceProvider.GetRequiredService<ITransactionUnitOfWork<TransactionDbContext>>();
        try
        {
            appContext.Database.Migrate();

            DataSeeder.Seed(unitOfWork);
        }
        catch (Exception ex)
        {
            logger.Error(Constants.ApplicationMessages.ERROR_DB_MIGRATION,
                ex.Message,
                ex.StackTrace);
        }
        return webApp;
    }
}
