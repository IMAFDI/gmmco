﻿using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;

namespace SafetyApp.Data.Transaction.Extensions;

public static class DataSeeder
{
    public static void Seed(ITransactionUnitOfWork<TransactionDbContext> unitOfWork)
    {
#if DEBUG

#endif

        unitOfWork.SaveChanges();
    }
}
