﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace SafetyApp.Data.Transaction.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "FN_SAFETYAPP_TXN");

            migrationBuilder.CreateTable(
                name: "EN_MSTR_FormType",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FormTypeName = table.Column<string>(type: "text", nullable: false),
                    FormTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_FormType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EN_MSTR_IncidentType",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    IncidentTypeName = table.Column<string>(type: "text", nullable: false),
                    IncidentTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_IncidentType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EN_MSTR_Location",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    LocationName = table.Column<string>(type: "text", nullable: false),
                    LocationCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_Location", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EN_MSTR_PermitType",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PermitTypeName = table.Column<string>(type: "text", nullable: false),
                    PermitTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_PermitType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EN_MSTR_User",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    USER_ID = table.Column<int>(type: "integer", nullable: false),
                    EmployeeId = table.Column<int>(type: "integer", nullable: false),
                    USER_NAME = table.Column<string>(type: "text", nullable: false),
                    USER_LOGIN_ID = table.Column<string>(type: "text", nullable: false),
                    PASSWORD = table.Column<string>(type: "text", nullable: false),
                    Designation_id = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true),
                    UserName = table.Column<string>(type: "text", nullable: true),
                    NormalizedUserName = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    NormalizedEmail = table.Column<string>(type: "text", nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    PasswordHash = table.Column<string>(type: "text", nullable: true),
                    SecurityStamp = table.Column<string>(type: "text", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_User", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EN_MSTR_Workstation",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    WorkstationName = table.Column<string>(type: "text", nullable: false),
                    WorkstationCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EN_MSTR_Workstation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TB_EN_TXN_Incidents",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    IncidentId = table.Column<Guid>(type: "uuid", nullable: false),
                    InjuryType = table.Column<string>(type: "text", nullable: false),
                    TreatmentProvided = table.Column<string>(type: "text", nullable: false),
                    Description = table.Column<string>(type: "text", nullable: false),
                    RootCauseForTheIncident = table.Column<string>(type: "text", nullable: false),
                    ReportedBy = table.Column<int>(type: "integer", nullable: false),
                    ReportedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    Remarks = table.Column<string>(type: "text", nullable: false),
                    ClosedBy = table.Column<int>(type: "integer", nullable: true),
                    ClosedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    CreatedId = table.Column<int>(type: "integer", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedId = table.Column<int>(type: "integer", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    DeletedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DeletedBy = table.Column<int>(type: "integer", nullable: true),
                    RecordSourceName = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_EN_TXN_Incidents", x => x.IncidentId);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_FRIInjuredPeople",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    FirstInformationReportId = table.Column<Guid>(type: "uuid", nullable: false),
                    EmployeeId = table.Column<int>(type: "integer", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_FRIInjuredPeople", x => x.FirstInformationReportId);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_FormsData",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    FormTypeId = table.Column<int>(type: "integer", nullable: false),
                    FormData = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_FormsData", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TB_TXN_FormsData_EN_MSTR_FormType_FormTypeId",
                        column: x => x.FormTypeId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_FormType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_FirstInFormationReport",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    IncidentTypeId = table.Column<int>(type: "integer", nullable: false),
                    LocationHeadId = table.Column<int>(type: "integer", nullable: false),
                    LocationId = table.Column<int>(type: "integer", nullable: false),
                    Branch = table.Column<string>(type: "text", nullable: false),
                    Dept = table.Column<string>(type: "text", nullable: false),
                    TotalNumberOfPeopleInjured = table.Column<int>(type: "integer", nullable: false),
                    AccidentDateTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    WorkStartHourAccidentDay = table.Column<TimeSpan>(type: "interval", nullable: false),
                    AccidentDescription = table.Column<string>(type: "text", nullable: false),
                    InjuredPersonActivityAtAccident = table.Column<string>(type: "text", nullable: false),
                    IsAccidentCausedByMachinery = table.Column<bool>(type: "boolean", nullable: false),
                    NameAndPartOfMachinery = table.Column<string>(type: "text", nullable: false),
                    IsMachineMovedByMechanicalPower = table.Column<bool>(type: "boolean", nullable: false),
                    NameAndAddressOfWitnesses = table.Column<string>(type: "text", nullable: false),
                    NatureExtentLocationOfInjury = table.Column<string>(type: "text", nullable: false),
                    TreatmentProviderName = table.Column<string>(type: "text", nullable: false),
                    TreatmentProviderAddress = table.Column<string>(type: "text", nullable: false),
                    LossTimeOccurred = table.Column<bool>(type: "boolean", nullable: false),
                    LossTimeStartDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    LossTimeEndDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    PropertyLossDetails = table.Column<string>(type: "text", nullable: false),
                    IsInjuiredPersonDied = table.Column<bool>(type: "boolean", nullable: false),
                    DeathDateTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    PostMortemDateTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    PostMortemProviderName = table.Column<string>(type: "text", nullable: false),
                    PostMortemProviderAddress = table.Column<string>(type: "text", nullable: false),
                    NoPostMortemReason = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_FirstInFormationReport", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TB_TXN_FirstInFormationReport_EN_MSTR_IncidentType_Incident~",
                        column: x => x.IncidentTypeId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_IncidentType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TB_TXN_FirstInFormationReport_EN_MSTR_Location_LocationId",
                        column: x => x.LocationId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_Location",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_PermitToWork",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    PermitId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PermitTypeId = table.Column<int>(type: "integer", nullable: false),
                    FormatNo = table.Column<string>(type: "text", nullable: false),
                    IssueNo = table.Column<int>(type: "integer", nullable: false),
                    IssueDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AmendmentNo = table.Column<int>(type: "integer", nullable: true),
                    AmendmentDate = table.Column<DateOnly>(type: "date", nullable: true),
                    DateOfPermit = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    TimeOfPermit = table.Column<TimeSpan>(type: "interval", nullable: false),
                    PermitNo = table.Column<string>(type: "text", nullable: false),
                    ValidFrom = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ValidTo = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Plant = table.Column<string>(type: "text", nullable: false),
                    AreaLocation = table.Column<string>(type: "text", nullable: false),
                    EquipmentMachines = table.Column<string>(type: "text", nullable: false),
                    ContractorName = table.Column<string>(type: "text", nullable: false),
                    ManpowerCount = table.Column<int>(type: "integer", nullable: false),
                    SpecificWorkActivity = table.Column<string>(type: "text", nullable: false),
                    DescriptionActivity = table.Column<string>(type: "text", nullable: false),
                    ChecklistJson = table.Column<string>(type: "text", nullable: false),
                    InsuranceNumber = table.Column<string>(type: "text", nullable: false),
                    AuthorizedBy = table.Column<string>(type: "text", nullable: false),
                    ExtensionFrom = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ExtensionTo = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ExtensionSignBy = table.Column<string>(type: "text", nullable: false),
                    PermitClosedOn = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ClosedBy = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_PermitToWork", x => x.PermitId);
                    table.ForeignKey(
                        name: "FK_TB_TXN_PermitToWork_EN_MSTR_PermitType_PermitTypeId",
                        column: x => x.PermitTypeId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_PermitType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_Notifications",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    NotificationId = table.Column<Guid>(type: "uuid", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    IncidentId = table.Column<Guid>(type: "uuid", nullable: false),
                    Message = table.Column<string>(type: "text", nullable: false),
                    IsRead = table.Column<bool>(type: "boolean", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_Notifications", x => x.NotificationId);
                    table.ForeignKey(
                        name: "FK_TB_TXN_Notifications_EN_MSTR_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_EN_TXN_NearMissReports",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    ReportId = table.Column<Guid>(type: "uuid", nullable: false),
                    IncidentId = table.Column<Guid>(type: "uuid", nullable: false),
                    PotentialHazards = table.Column<string>(type: "text", nullable: false),
                    PreventiveActions = table.Column<string>(type: "text", nullable: false),
                    LocationId = table.Column<int>(type: "integer", nullable: false),
                    WorkstationId = table.Column<int>(type: "integer", nullable: false),
                    UnsafeAct = table.Column<bool>(type: "boolean", nullable: false),
                    UnsafeCondition = table.Column<bool>(type: "boolean", nullable: false),
                    TempSolution = table.Column<string>(type: "text", nullable: false),
                    PermanentSolution = table.Column<string>(type: "text", nullable: false),
                    DateOfCompleted = table.Column<DateOnly>(type: "date", nullable: true),
                    VerifiedBy = table.Column<int>(type: "integer", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_EN_TXN_NearMissReports", x => x.ReportId);
                    table.ForeignKey(
                        name: "FK_TB_EN_TXN_NearMissReports_EN_MSTR_Location_LocationId",
                        column: x => x.LocationId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_Location",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TB_EN_TXN_NearMissReports_EN_MSTR_Workstation_WorkstationId",
                        column: x => x.WorkstationId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_Workstation",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_FirstAidReport",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    ReportId = table.Column<Guid>(type: "uuid", nullable: false),
                    IncidentId = table.Column<Guid>(type: "uuid", nullable: false),
                    ItemUsed = table.Column<string>(type: "text", nullable: false),
                    ExperienceInGmmco = table.Column<float>(type: "real", nullable: false),
                    ReportingManager = table.Column<int>(type: "integer", nullable: false),
                    IncidentTypeId = table.Column<int>(type: "integer", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_FirstAidReport", x => x.ReportId);
                    table.ForeignKey(
                        name: "FK_TB_TXN_FirstAidReport_EN_MSTR_IncidentType_IncidentTypeId",
                        column: x => x.IncidentTypeId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "EN_MSTR_IncidentType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TB_TXN_FirstAidReport_TB_EN_TXN_Incidents_IncidentId",
                        column: x => x.IncidentId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "TB_EN_TXN_Incidents",
                        principalColumn: "IncidentId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_AccidentDetailedReport",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    FirstInFormationReportId = table.Column<Guid>(type: "uuid", nullable: false),
                    ChronologyOfEvents = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_AccidentDetailedReport", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TB_TXN_AccidentDetailedReport_TB_TXN_FirstInFormationReport~",
                        column: x => x.FirstInFormationReportId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "TB_TXN_FirstInFormationReport",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_TXN_IncidentAttachment",
                schema: "FN_SAFETYAPP_TXN",
                columns: table => new
                {
                    AttachmentId = table.Column<Guid>(type: "uuid", nullable: false),
                    IncidentId = table.Column<Guid>(type: "uuid", nullable: false),
                    AccidentDetailedReportId = table.Column<Guid>(type: "uuid", nullable: false),
                    FilePath = table.Column<string>(type: "text", nullable: false),
                    UploadedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_TXN_IncidentAttachment", x => x.AttachmentId);
                    table.ForeignKey(
                        name: "FK_TB_TXN_IncidentAttachment_TB_TXN_AccidentDetailedReport_Acc~",
                        column: x => x.AccidentDetailedReportId,
                        principalSchema: "FN_SAFETYAPP_TXN",
                        principalTable: "TB_TXN_AccidentDetailedReport",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TB_EN_TXN_NearMissReports_LocationId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_EN_TXN_NearMissReports",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_EN_TXN_NearMissReports_WorkstationId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_EN_TXN_NearMissReports",
                column: "WorkstationId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_AccidentDetailedReport_FirstInFormationReportId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_AccidentDetailedReport",
                column: "FirstInFormationReportId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_FirstAidReport_IncidentId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_FirstAidReport",
                column: "IncidentId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_FirstAidReport_IncidentTypeId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_FirstAidReport",
                column: "IncidentTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_FirstInFormationReport_IncidentTypeId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_FirstInFormationReport",
                column: "IncidentTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_FirstInFormationReport_LocationId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_FirstInFormationReport",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_FormsData_FormTypeId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_FormsData",
                column: "FormTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_IncidentAttachment_AccidentDetailedReportId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_IncidentAttachment",
                column: "AccidentDetailedReportId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_Notifications_UserId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_Notifications",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_TXN_PermitToWork_PermitTypeId",
                schema: "FN_SAFETYAPP_TXN",
                table: "TB_TXN_PermitToWork",
                column: "PermitTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TB_EN_TXN_NearMissReports",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_FirstAidReport",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_FormsData",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_FRIInjuredPeople",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_IncidentAttachment",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_Notifications",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_PermitToWork",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_Workstation",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_EN_TXN_Incidents",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_FormType",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_AccidentDetailedReport",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_User",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_PermitType",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "TB_TXN_FirstInFormationReport",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_IncidentType",
                schema: "FN_SAFETYAPP_TXN");

            migrationBuilder.DropTable(
                name: "EN_MSTR_Location",
                schema: "FN_SAFETYAPP_TXN");
        }
    }
}
