﻿namespace SafetyApp.Core.Data.Interface;


public interface IUnitOfWork<T> : IDisposable where T : class
{
    /// <summary>
    /// Persist all changes into persistence as single operation.
    /// </summary>
    /// <returns>Number of record that changed.</returns>
    int SaveChanges();
}
