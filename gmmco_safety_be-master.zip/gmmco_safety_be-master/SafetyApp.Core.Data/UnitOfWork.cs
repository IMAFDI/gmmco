﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Core.Data;

public class UnitOfWork<T> : IUnitOfWork<T> where T : DbContext
{
    /// <summary>
    /// Indicates the object is already disposed.
    /// </summary>
    protected bool _isDisposed;

    /// <summary>
    /// Hold the database context.
    /// </summary>
    protected DbContext _dbContext;

    /// <summary>
    /// Initializes a new instance of the <see cref="UnitOfWork{T}" /> class.
    /// </summary>
    /// <param name="dbContext">The DB context.</param>
    public UnitOfWork(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    /// <summary>
    /// Finalizes an instance of the <see cref="UnitOfWork{T}"/> class.
    /// </summary>
    ~UnitOfWork()
    {
        Dispose(true);
    }

    /// <summary>
    /// Persist all changes into persistence as single operation.
    /// </summary>
    /// <returns>
    /// Number of record that changed.
    /// </returns>
    public int SaveChanges()
    {
        return _dbContext.SaveChanges();
    }

    /// <summary>
    /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Releases unmanaged and - optionally - managed resources.
    /// </summary>
    /// <param name="disposing"><c>true</c> indicates the disposed is called from Dispose method; <c>false</c> indicates that the method is called from finalize method.</param>
    private void Dispose(bool disposing)
    {
        // Already been disposed, then do nothing
        if (_isDisposed)
        {
            return;
        }

        // Release all unmanaged resources
        if (disposing)
        {
            if (_dbContext != null)
            {
                _dbContext.Dispose();
            }
        }

        _isDisposed = true;
    }
}
