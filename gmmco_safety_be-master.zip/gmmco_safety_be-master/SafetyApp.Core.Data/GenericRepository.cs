﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Core.Data;

public class GenericRepository<TKey, TEntity> : IGenericRepository<TKey, TEntity>
    where TKey : IEquatable<TKey>
    where TEntity : EntityBase
{
    /// <summary>
    /// The database context.
    /// </summary>
    protected readonly DbContext _dbContext;

    /// <summary>
    /// The table.
    /// </summary>
    protected readonly DbSet<TEntity> _table;

    /// <summary>
    /// Initializes a new instance of the <see cref="GenericRepository{TKey, TEntity}"/> class.
    /// </summary>
    /// <param name="dbContext">The database context.</param>
    public GenericRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
        _table = _dbContext.Set<TEntity>();
    }

    /// <summary>
    /// Gets entity by the specified identifier.
    /// </summary>
    /// <param name="id">The identifier.</param>
    /// <returns>
    /// The entity.
    /// </returns>
    public virtual TEntity Get(TKey id)
    {
        return _table.Find(id);
    }

    /// <summary>
    /// Gets all entities.
    /// </summary>
    /// <returns>
    /// The entities.
    /// </returns>
    public virtual IEnumerable<TEntity> GetAll()
    {
        return _table.ToList();
    }

    /// <summary>
    /// Gets the entities by criteria, ordering and paging.
    /// </summary>
    /// <param name="filter">The filter.</param>
    /// <param name="orderBy">The order by.</param>
    /// <param name="isOrderAscending">if set to <c>true</c> order ascending.</param>
    /// <param name="pageNumber">The page number.</param>
    /// <param name="pageSize">Size of the page.</param>
    /// <returns>
    /// The entities.
    /// </returns>
    public virtual IEnumerable<TEntity> GetByCriteria(
        Func<TEntity, bool> filter,
        Func<TEntity, bool> orderBy,
        bool isOrderAscending,
        int pageNumber = 0,
        int pageSize = 10)
    {
        var res = _table.Where(filter).Skip(pageNumber * pageSize).Take(pageSize);
        if (isOrderAscending) res = res.OrderBy(orderBy);
        else res = res.OrderByDescending(orderBy);

        return res.ToList();
    }

    /// <summary>
    /// Adds the specified entity.
    /// </summary>
    /// <param name="entity">The entity.</param>
    /// <returns>
    /// The added entity.
    /// </returns>
    public virtual TEntity Add(TEntity entity)
    {
        var now = DateTime.UtcNow;

        entity.CREATED_DATE = now;
        entity.UPDATED_DATE = now;

        var addedEntity = _table.Add(entity);
        return addedEntity.Entity;
    }

    /// <summary>
    /// Updates the specified entity.
    /// </summary>
    /// <param name="id">The identifier.</param>
    /// <param name="entity">The entity.</param>
    /// <returns>
    /// The updated entity.
    /// </returns>
    public virtual TEntity Update(TKey id, TEntity entity)
    {
        var now = DateTime.UtcNow;

        var existing = _table.Find(id);
        if (existing != null)
        {
            entity.CREATED_ID = existing.CREATED_ID;
            entity.CREATED_DATE = existing.CREATED_DATE;
            entity.RECORD_SOURCE_NAME = existing.RECORD_SOURCE_NAME;
            entity.UPDATED_DATE = now;

            _dbContext.Entry(existing).CurrentValues.SetValues(entity);
        }
        return entity;
    }

    /// <summary>
    /// Deletes the specified entity.
    /// </summary>
    /// <param name="id">The identifier.</param>
    /// <param name="entity">The entity.</param>
    public virtual void Delete(TKey id, TEntity entity)
    {
        var existing = _table.Find(id);
        if (existing != null) _table.Remove(existing);
    }
}
