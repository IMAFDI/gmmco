﻿namespace SafetyApp.Transaction.Service.Interface
{
    public interface IFirstAidReportService
    {
        /// <summary>
        /// Creates the status.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns>The created status.</returns>
        EN_TXN_FirstAidReport CreateStatus(EN_TXN_FirstAidReport data);

        /// <summary>
        /// Updates the status.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns>The updated status.</returns>
        EN_TXN_FirstAidReport UpdateStatus(EN_TXN_FirstAidReport data);

        /// <summary>
        /// Deletes the status.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The deleted status.</returns>
        EN_TXN_FirstAidReport DeleteStatus(Guid id);

        /// <summary>
        /// Finds the status by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The status.</returns>
        EN_TXN_FirstAidReport FindStatusById(Guid id);

        /// <summary>
        /// Finds all.
        /// </summary>
        /// <param name="totalRows">The total rows.</param>
        /// <param name="pageNo">The page no.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="orderBy">The order by.</param>
        /// <param name="orderType">Type of the order.</param>
        /// <returns>
        /// The list of status.
        /// </returns>
        IEnumerable<EN_TXN_FirstAidReport> FindAll(
            out int totalRows, int pageNo, int pageSize, string orderBy, string orderType);
    }
}
