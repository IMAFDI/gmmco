﻿namespace SafetyApp.Transaction.Service.Interface
{
    public interface IIncidentService
    {

        EN_TXN_Incidents FindIncidentById(Guid id);

        IEnumerable<EN_TXN_Incidents> FindAll(
            out int totalRows, int pageNo, int pageSize, string orderBy, string orderType);
    }
}
