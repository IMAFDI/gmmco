﻿namespace SafetyApp.Transaction.Service.Interface
{
    public interface INearMissReportService
    {
        EN_TXN_NearMissReport CreateReport(EN_TXN_NearMissReport data);
        IEnumerable<EN_TXN_NearMissReport> GetAllReports();
        EN_TXN_NearMissReport GetReportById(Guid id);
    }

}
