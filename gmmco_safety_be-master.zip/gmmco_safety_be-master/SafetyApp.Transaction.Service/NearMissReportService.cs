﻿using CommunityToolkit.Diagnostics;
using SafetyApp.Core;
using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;
using SafetyApp.Transaction.Service.Interface;
using System.Globalization;

namespace SafetyApp.Transaction.Service;

public class NearMissReportService : INearMissReportService
{
    private readonly ITransactionUnitOfWork<TransactionDbContext> _unitOfWork;


    public NearMissReportService(
        ITransactionUnitOfWork<TransactionDbContext> unitOfWork)
    {
        if (unitOfWork != null)
        {
            Guard.IsNotNull(unitOfWork);
            _unitOfWork = unitOfWork;
        }

    }

    public EN_TXN_NearMissReport CreateReport(EN_TXN_NearMissReport data)
    {
        Guard.IsNotNull(data);
        Guard.IsNotDefault(data.ReportId);
        Guard.IsNotDefault(data.IncidentId);
        Guard.IsNotNullOrEmpty(data.PotentialHazards);
        Guard.IsNotNullOrEmpty(data.PreventiveActions);

        var existingEntity = _unitOfWork.NearMissReportRepository.GetAll()
            .FirstOrDefault(d => d.IncidentId == data.IncidentId
                              && d.PotentialHazards.Equals(data.PotentialHazards, StringComparison.InvariantCultureIgnoreCase)
                              && d.PreventiveActions.Equals(data.PreventiveActions, StringComparison.InvariantCultureIgnoreCase));

        if (existingEntity != null)
        {
            throw new DomainException(
                MessageFactory.CreateErrorMessage(
                    string.Format(CultureInfo.InvariantCulture,
                        "A Near Miss Report with Potential Hazard '{0}' and Preventive Action '{1}' already exists for this incident.",
                        data.PotentialHazards,
                        data.PreventiveActions),
                    nameof(data.PotentialHazards)));
        }

        _unitOfWork.NearMissReportRepository.Add(data);
        _unitOfWork.SaveChanges();

        return _unitOfWork.NearMissReportRepository.Get(data.ReportId);
    }


    public IEnumerable<EN_TXN_NearMissReport> GetAllReports()
    {
        return _unitOfWork.NearMissReportRepository.GetAll();
    }

    public EN_TXN_NearMissReport GetReportById(Guid id)
    {
        return _unitOfWork.NearMissReportRepository.Get(id);
    }
}