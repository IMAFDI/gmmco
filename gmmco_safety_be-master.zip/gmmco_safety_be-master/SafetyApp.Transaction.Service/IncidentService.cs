﻿using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;
using SafetyApp.Transaction.Service.Interface;

namespace SafetyApp.Transaction.Service;

public class IncidentService : IIncidentService
{
    /// <summary>
    /// Unit of work.
    /// </summary>
    private ITransactionUnitOfWork<TransactionDbContext> _unitOfWork;

    /// <summary>
    /// Validator.
    /// </summary>
    //private IValidator<EN_TXN_Incidents> _validator;

    /// <summary>
    /// Initializes a new instance of the <see cref="StatusService" /> class.
    /// </summary>
    /// <param name="unitOfWork">The unit of work.</param>
    /// <param name="validator">The validator.</param>
    public IncidentService(
        ITransactionUnitOfWork<TransactionDbContext> unitOfWork
        //,IValidator<EN_TXN_Incidents> validator
        )
    {
        if (unitOfWork != null)
        {
            _unitOfWork = unitOfWork;
        }

        //_validator = validator;
    }

    /// <summary>
    /// Finds the status by identifier.
    /// </summary>
    /// <param name="id">The identifier.</param>
    /// <returns>
    /// The status.
    /// </returns>
    public EN_TXN_Incidents FindIncidentById(Guid id)
    {
        return _unitOfWork.IncidentsRepository.Get(id);
    }

    /// <summary>
    /// Finds all.
    /// </summary>
    /// <param name="totalRows">The total rows.</param>
    /// <param name="pageNo">The page no.</param>
    /// <param name="pageSize">Size of the page.</param>
    /// <param name="orderBy">The order by.</param>
    /// <param name="orderType">Type of the order.</param>
    /// <returns>
    /// The list of status.
    /// </returns>
    public IEnumerable<EN_TXN_Incidents> FindAll(
        out int totalRows, int pageNo, int pageSize, string orderBy, string orderType)
    {
        var result = _unitOfWork.IncidentsRepository.GetAll();

        var isAsc = orderType.Equals("asc", StringComparison.InvariantCultureIgnoreCase);

        result = orderBy.ToUpper() switch
        {
            "CREATED_DATE" => isAsc ? result.OrderBy(d => d.CREATED_DATE) : result.OrderByDescending(d => d.CREATED_DATE),
            "UPDATED_DATE" => isAsc ? result.OrderBy(d => d.UPDATED_DATE) : result.OrderByDescending(d => d.UPDATED_DATE),
            _ => isAsc ? result.OrderBy(d => d.CREATED_DATE) : result.OrderByDescending(d => d.CREATED_DATE),
        };

        totalRows = result.Count();

        return result.Skip((pageNo - 1) * pageSize).Take(pageSize);
    }
}
