﻿namespace SafetyApp.Transaction.Service
{
    public class Class1
    {

    }
}
