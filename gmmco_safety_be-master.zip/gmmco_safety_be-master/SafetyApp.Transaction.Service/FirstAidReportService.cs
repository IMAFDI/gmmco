﻿using CommunityToolkit.Diagnostics;
using SafetyApp.Core;
using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;
using SafetyApp.Transaction.Service.Interface;
using System.Globalization;
namespace SafetyApp.Transaction.Service
{
    public class FirstAidReportService : IFirstAidReportService
    {
        private readonly ITransactionUnitOfWork<TransactionDbContext> _unitOfWork;

        public FirstAidReportService(ITransactionUnitOfWork<TransactionDbContext> unitOfWork)
        {
            Guard.IsNotNull(unitOfWork);
            _unitOfWork = unitOfWork;
        }


        public EN_TXN_FirstAidReport CreateStatus(EN_TXN_FirstAidReport data)
        {
            Guard.IsNotNull(data);
            Guard.IsNotDefault(data.ReportId);
            Guard.IsNotDefault(data.IncidentId);
            Guard.IsNotNullOrEmpty(data.ItemUsed);

            var existingEntity = _unitOfWork.FirstAidReportRepository.GetAll()
                .FirstOrDefault(d => d.IncidentId == data.IncidentId
                                  && d.ItemUsed.Equals(data.ItemUsed, StringComparison.InvariantCultureIgnoreCase));

            if (existingEntity != null)
            {
                throw new DomainException(
                    MessageFactory.CreateErrorMessage(
                        string.Format(CultureInfo.InvariantCulture,
                            "First aid report with Item '{0}' already exists for this incident.",
                            data.ItemUsed),
                        nameof(data.ItemUsed)));
            }

            _unitOfWork.FirstAidReportRepository.Add(data);
            _unitOfWork.SaveChanges();

            return _unitOfWork.FirstAidReportRepository.Get(data.ReportId);
        }

        public EN_TXN_FirstAidReport UpdateStatus(EN_TXN_FirstAidReport data)
        {
            Guard.IsNotNull(data);
            Guard.IsNotDefault(data.ReportId);

            var existingEntity = _unitOfWork.FirstAidReportRepository.Get(data.ReportId);
            Guard.IsNotNull(existingEntity, nameof(data.ReportId));

            _unitOfWork.FirstAidReportRepository.Update(data.ReportId, data);
            _unitOfWork.SaveChanges();

            return _unitOfWork.FirstAidReportRepository.Get(data.ReportId);
        }


        public EN_TXN_FirstAidReport DeleteStatus(Guid id)
        {
            Guard.IsNotDefault(id, nameof(id));

            var existingEntity = _unitOfWork.FirstAidReportRepository.Get(id);
            Guard.IsNotNull(existingEntity, nameof(id));

            _unitOfWork.FirstAidReportRepository.Delete(existingEntity.ReportId, existingEntity);
            _unitOfWork.SaveChanges();

            return existingEntity;
        }

        public EN_TXN_FirstAidReport FindStatusById(Guid id)
        {
            Guard.IsNotDefault(id, nameof(id));
            var data = _unitOfWork.FirstAidReportRepository.Get(id);
            data.Incident = _unitOfWork.IncidentsRepository.Get(data.IncidentId);

            return data;
        }


        public IEnumerable<EN_TXN_FirstAidReport> FindAll(
            out int totalRows, int pageNo, int pageSize, string orderBy, string orderType)
        {
            var result = _unitOfWork.FirstAidReportRepository.GetAll();

            var isAsc = orderType.Equals("asc", StringComparison.InvariantCultureIgnoreCase);

            result = orderBy.ToUpper() switch
            {
                "ITEMUSED" => isAsc ? result.OrderBy(d => d.ItemUsed) : result.OrderByDescending(d => d.ItemUsed),
                "EXPERIENCEINGMMCO" => isAsc ? result.OrderBy(d => d.ExperienceInGmmco) : result.OrderByDescending(d => d.ExperienceInGmmco),
                _ => isAsc ? result.OrderBy(d => d.ReportId) : result.OrderByDescending(d => d.ReportId),
            };

            totalRows = result.Count();

            return result.Skip((pageNo - 1) * pageSize).Take(pageSize);
        }
    }
}
