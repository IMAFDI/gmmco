﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace SafetyApp.Data.Master.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "FN_SAFETYAPP_MASTER");

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    ROLE_ID = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ROLE_NAME = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true),
                    Id = table.Column<int>(type: "integer", nullable: false),
                    Name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.ROLE_ID);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_Employee",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    EmployeeId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FirstName = table.Column<string>(type: "text", nullable: false),
                    LastName = table.Column<string>(type: "text", nullable: false),
                    DateOfJoining = table.Column<DateOnly>(type: "date", nullable: false),
                    ContributionLevel = table.Column<string>(type: "text", nullable: false),
                    DirectManager = table.Column<string>(type: "text", nullable: false),
                    DirectManagerEmail = table.Column<string>(type: "text", nullable: false),
                    DirectManagerEmployeeId = table.Column<int>(type: "integer", nullable: false),
                    Division = table.Column<string>(type: "text", nullable: false),
                    SubEmployeeType = table.Column<string>(type: "text", nullable: false),
                    EmployeeStatus = table.Column<bool>(type: "boolean", nullable: false),
                    EmployeeType = table.Column<int>(type: "integer", nullable: false),
                    JobLevel = table.Column<string>(type: "text", nullable: false),
                    PsGroup = table.Column<string>(type: "text", nullable: false),
                    PsLevel = table.Column<string>(type: "text", nullable: false),
                    SBU = table.Column<string>(type: "text", nullable: false),
                    DateOfBirth = table.Column<DateOnly>(type: "date", nullable: false),
                    CompanyEmailId = table.Column<string>(type: "text", nullable: false),
                    Gender = table.Column<string>(type: "text", nullable: false),
                    OfficeCity = table.Column<string>(type: "text", nullable: false),
                    OfficeLocation = table.Column<string>(type: "text", nullable: false),
                    OfficeRegion = table.Column<string>(type: "text", nullable: false),
                    OfficeState = table.Column<string>(type: "text", nullable: false),
                    OfficeMobileNo = table.Column<string>(type: "text", nullable: false),
                    GmmcoDept = table.Column<int>(type: "integer", nullable: false),
                    SafetyRole = table.Column<int>(type: "integer", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_Employee", x => x.EmployeeId);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_FormType",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FormTypeName = table.Column<string>(type: "text", nullable: false),
                    FormTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_FormType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_IncidentType",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    IncidentTypeName = table.Column<string>(type: "text", nullable: false),
                    IncidentTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_IncidentType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_Location",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    LocationName = table.Column<string>(type: "text", nullable: false),
                    LocationCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_Location", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_PermitType",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PermitTypeName = table.Column<string>(type: "text", nullable: false),
                    PermitTypeCode = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_PermitType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TB_MSTR_Workstation",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    WorkstationName = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    WorkstationCode = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_MSTR_Workstation", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RoleId = table.Column<int>(type: "integer", nullable: false),
                    ClaimType = table.Column<string>(type: "text", nullable: true),
                    ClaimValue = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetRoles",
                        principalColumn: "ROLE_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    USER_ID = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    EmployeeId = table.Column<int>(type: "integer", nullable: false),
                    USER_NAME = table.Column<string>(type: "text", nullable: false),
                    USER_LOGIN_ID = table.Column<string>(type: "text", nullable: false),
                    PASSWORD = table.Column<string>(type: "text", nullable: false),
                    Designation_id = table.Column<string>(type: "text", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true),
                    Id = table.Column<int>(type: "integer", nullable: false),
                    UserName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    PasswordHash = table.Column<string>(type: "text", nullable: true),
                    SecurityStamp = table.Column<string>(type: "text", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.USER_ID);
                    table.ForeignKey(
                        name: "FK_AspNetUsers_TB_MSTR_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "TB_MSTR_Employee",
                        principalColumn: "EmployeeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    ClaimType = table.Column<string>(type: "text", nullable: true),
                    ClaimValue = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetUsers",
                        principalColumn: "USER_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "text", nullable: false),
                    ProviderKey = table.Column<string>(type: "text", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "text", nullable: true),
                    UserId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetUsers",
                        principalColumn: "USER_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    USER_ROLE_ID = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    USER_ID = table.Column<int>(type: "integer", nullable: false),
                    ROLE_ID = table.Column<int>(type: "integer", nullable: false),
                    CREATED_ID = table.Column<int>(type: "integer", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UPDATED_ID = table.Column<int>(type: "integer", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IS_ACTIVE = table.Column<bool>(type: "boolean", nullable: false),
                    DELETED_AT = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    DELETED_BY = table.Column<int>(type: "integer", nullable: true),
                    RECORD_SOURCE_NAME = table.Column<string>(type: "text", nullable: true),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    RoleId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => x.USER_ROLE_ID);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_ROLE_ID",
                        column: x => x.ROLE_ID,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetRoles",
                        principalColumn: "ROLE_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetRoles",
                        principalColumn: "ROLE_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_USER_ID",
                        column: x => x.USER_ID,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetUsers",
                        principalColumn: "USER_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetUsers",
                        principalColumn: "USER_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                schema: "FN_SAFETYAPP_MASTER",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    LoginProvider = table.Column<string>(type: "text", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: false),
                    Value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalSchema: "FN_SAFETYAPP_MASTER",
                        principalTable: "AspNetUsers",
                        principalColumn: "USER_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_ROLE_ID",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserRoles",
                column: "ROLE_ID");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_USER_ID",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserRoles",
                column: "USER_ID");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_UserId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUserRoles",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_EmployeeId",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUsers",
                column: "EmployeeId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                schema: "FN_SAFETYAPP_MASTER",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_FormType",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_IncidentType",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_Location",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_PermitType",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_Workstation",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetRoles",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "AspNetUsers",
                schema: "FN_SAFETYAPP_MASTER");

            migrationBuilder.DropTable(
                name: "TB_MSTR_Employee",
                schema: "FN_SAFETYAPP_MASTER");
        }
    }
}
