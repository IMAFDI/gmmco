﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SafetyApp.Core;
using SafetyApp.Master;
using SafetyApp.Master.Data;
using SafetyApp.Master.Data.Interface;
using Serilog;

namespace SafetyApp.Data.Master.Extensions
{
    public static class MigrationManager
    {
        public static WebApplication MigrateDatabaseMaster(this WebApplication webApp, ILogger logger)
        {
            using var scope = webApp.Services.CreateScope();
            using var appContext = scope.ServiceProvider.GetRequiredService<MasterMigrationDbContext>();
            using var unitOfWork = scope.ServiceProvider.GetRequiredService<IMasterUnitOfWork<MasterDbContext>>();
            using var userManager = scope.ServiceProvider.GetRequiredService<UserManager<EN_MSTR_User>>();
            try
            {
                appContext.Database.Migrate();

                DataSeeder.Seed(unitOfWork, userManager);
            }
            catch (Exception ex)
            {
                logger.Error(Constants.ApplicationMessages.ERROR_DB_MIGRATION,
                    ex.Message,
                    ex.StackTrace);
            }
            return webApp;
        }
    }
}
