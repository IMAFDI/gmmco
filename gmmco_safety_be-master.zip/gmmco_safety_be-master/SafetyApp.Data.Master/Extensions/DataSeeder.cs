﻿using Microsoft.AspNetCore.Identity;
using SafetyApp.Master;
using SafetyApp.Master.Data;
using SafetyApp.Master.Data.Interface;

namespace SafetyApp.Data.Master.Extensions;

public static class DataSeeder
{
    public static void Seed(
        IMasterUnitOfWork<MasterDbContext> unitOfWork,
        UserManager<EN_MSTR_User> userManager)
    {
        //if (!unitOfWork.StatusRepository.GetAll().Any())
        //{
        //    foreach (var data in DataStub.StatusData)
        //    {
        //        unitOfWork.StatusRepository.Add(data);
        //    }
        //}

        //if (!unitOfWork.RoleRepository.GetAll().Any())
        //{
        //    foreach (var data in DataStub.RoleData)
        //    {
        //        unitOfWork.RoleRepository.Add(data);
        //    }
        //}

        unitOfWork.SaveChanges();
    }
}

