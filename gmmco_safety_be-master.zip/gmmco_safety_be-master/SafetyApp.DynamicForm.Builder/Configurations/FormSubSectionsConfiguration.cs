﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormSubSectionsConfiguration : IEntityTypeConfiguration<EN_DFB_MSTR_FormSubSections>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_MSTR_FormSubSections> builder)
        {
            builder.HasKey(table => table.Id);

            builder.Property(table => table.SubSectionName).HasMaxLength(100);
            builder.Property(table => table.SubSectionDesc).HasMaxLength(500);
            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);

            builder.HasOne<EN_DFB_MSTR_FormSections>()
                   .WithMany()
                   .HasForeignKey(table => table.SectionId);
        }
    }
}
