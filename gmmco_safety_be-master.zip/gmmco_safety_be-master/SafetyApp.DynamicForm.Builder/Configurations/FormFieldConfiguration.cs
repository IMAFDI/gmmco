﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Data.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormFieldConfiguration : IEntityTypeConfiguration<EN_DFB_MSTR_FormFieldConfiguration>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_MSTR_FormFieldConfiguration> builder)
        {

            builder.HasKey(table => table.Id);

            builder.Property(table => table.FieldDescription).HasMaxLength(8000);
            builder.Property(table => table.FieldOptions).HasMaxLength(8000);

            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);

            builder.HasOne<EN_DFB_MSTR_FormSections>()
                   .WithMany()
                   .HasForeignKey(table => table.SectionId);

            builder.HasOne<EN_DFB_MSTR_FormSubSections>()
                   .WithMany()
                   .HasForeignKey(table => table.SubSectionId);

            builder.HasOne<DFB_SMSTR_FormFieldType>()
                   .WithMany()
                   .HasForeignKey(table => table.FieldTypeId);
        }
    }
}
