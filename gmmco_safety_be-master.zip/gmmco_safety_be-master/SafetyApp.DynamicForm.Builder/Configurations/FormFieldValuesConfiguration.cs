﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormFieldValuesConfiguration : IEntityTypeConfiguration<EN_DFB_TRNSTN_FormFieldValues>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_TRNSTN_FormFieldValues> builder)
        {
            builder.HasKey(table => table.Id);

            builder.Property(table => table.FieldValue).HasMaxLength(8000);
            builder.Property(table => table.FieldRemarks).HasMaxLength(8000);
            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);

            builder.HasOne<EN_DFB_MSTR_FormFieldConfiguration>()
                   .WithMany()
                   .HasForeignKey(table => table.FieldId);
        }
    }
}
