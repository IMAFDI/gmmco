﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormPreDefinedAttributesConfiguration : IEntityTypeConfiguration<EN_DFB_SMSTR_FormPreDefinedAttributes>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_SMSTR_FormPreDefinedAttributes> builder)
        {
            builder.HasKey(table => table.Id);

            builder.Property(table => table.FieldType).HasMaxLength(100);
            builder.Property(table => table.FieldName).HasMaxLength(100);
            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);
        }
    }
}
