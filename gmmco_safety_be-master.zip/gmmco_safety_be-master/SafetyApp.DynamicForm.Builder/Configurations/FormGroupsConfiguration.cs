﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormGroupsConfiguration : IEntityTypeConfiguration<EN_DFB_MSTR_FormGroups>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_MSTR_FormGroups> builder)
        {
           
            builder.HasKey(table => table.Id);

            builder.Property(table => table.GroupName)
                   .HasMaxLength(100);
            builder.Property(table => table.GroupDesc)
                   .HasMaxLength(500);

            builder.Property(table => table.RECORD_SOURCE_NAME)
                   .HasMaxLength(100);
        }
    }
}
