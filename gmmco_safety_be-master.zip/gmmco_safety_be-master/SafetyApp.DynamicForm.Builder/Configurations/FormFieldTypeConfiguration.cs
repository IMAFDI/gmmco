﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormFieldTypeConfiguration : IEntityTypeConfiguration<DFB_SMSTR_FormFieldType>
    {
        public void Configure(EntityTypeBuilder<DFB_SMSTR_FormFieldType> builder)
        {
            builder.HasKey(table => table.Id);

            builder.Property(table => table.FieldType).HasMaxLength(100);
            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);
        }
    }
}
