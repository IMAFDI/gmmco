﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.DynamicFormBuilder.Configurations
{
    [ExcludeFromCodeCoverage]
    public class FormSectionsConfiguration : IEntityTypeConfiguration<EN_DFB_MSTR_FormSections>
    {
        public void Configure(EntityTypeBuilder<EN_DFB_MSTR_FormSections> builder)
        {
           
            builder.HasKey(table => table.Id);

            builder.Property(table => table.SectionName).HasMaxLength(100);
            builder.Property(table => table.SectionDesc).HasMaxLength(500);
            builder.Property(table => table.RECORD_SOURCE_NAME).HasMaxLength(100);

            builder.HasOne<EN_DFB_MSTR_Forms>()
                   .WithMany()
                   .HasForeignKey(table => table.FormId);
        }
    }
}
