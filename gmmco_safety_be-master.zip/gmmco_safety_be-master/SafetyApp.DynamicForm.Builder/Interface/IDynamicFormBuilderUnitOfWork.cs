﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;

namespace SafetyApp.DynamicFormBuilder.Data.Interface;

/// <summary>
/// Interface for Master Unit Of Work.
/// </summary>
/// <typeparam name="T">Type parameter.</typeparam>
public interface IDynamicFormBuilderUnitOfWork<T> : IUnitOfWork<T> where T : DbContext
{

}

