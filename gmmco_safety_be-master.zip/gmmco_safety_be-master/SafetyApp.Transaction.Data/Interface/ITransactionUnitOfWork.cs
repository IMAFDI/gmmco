﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Transaction.Data.Interface;

/// <summary>
/// Interface for Transaction Unit Of Work.
/// </summary>
/// <typeparam name="T">Type parameter.</typeparam>
public interface ITransactionUnitOfWork<T> : IUnitOfWork<T> where T : DbContext
{
    INearMissReportRepository NearMissReportRepository { get; set; }
    IIncidentRepository IncidentsRepository { get; set; }
    IFirstAidReportRepository FirstAidReportRepository { get; set; }
}

