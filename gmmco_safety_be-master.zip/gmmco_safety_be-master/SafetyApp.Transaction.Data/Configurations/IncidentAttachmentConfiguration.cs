﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class IncidentAttachmentConfiguration : IEntityTypeConfiguration<EN_TXN_IncidentAttachment>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_IncidentAttachment> builder)
        {

            builder.HasKey(table => table.AttachmentId);



            builder.HasOne(table => table.AccidentDetailedReport)
                .WithMany()
                .HasForeignKey(table => table.AccidentDetailedReportId);
        }
    }
}
