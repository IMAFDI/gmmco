﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;
using SafetyApp.Transaction;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class FirstInFormationReportConfiguration : IEntityTypeConfiguration<EN_TXN_FirstInFormationReport>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_FirstInFormationReport> builder)
        {

            builder.HasKey(table => table.Id);

            builder.HasOne(table => table.IncidentType)
                    .WithMany()
                    .HasForeignKey(table => table.IncidentTypeId);

            builder.HasOne(table => table.Location)
                    .WithMany()
                    .HasForeignKey(table => table.LocationId);

        }
    }
}
