﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class PermitToWorkConfiguration : IEntityTypeConfiguration<EN_TXN_PermitToWork>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_PermitToWork> builder)
        {
            // Primary Key
            builder.HasKey(table => table.PermitId);

            builder.HasOne(table => table.PermitType)
                .WithMany()
                .HasForeignKey(table => table.PermitTypeId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
