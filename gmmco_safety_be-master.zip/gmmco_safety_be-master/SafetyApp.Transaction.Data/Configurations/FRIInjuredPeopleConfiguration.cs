﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;
using SafetyApp.Transaction;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class FRIInjuredPeopleConfiguration : IEntityTypeConfiguration<EN_TXN_FRIInjuredPeople>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_FRIInjuredPeople> builder)
        {
            
            builder.HasKey(table => table.FirstInformationReportId);

            builder.HasOne(table => table.Employee)
                .WithMany()
                .HasForeignKey(table => table.EmployeeId);
        }
    }
}
