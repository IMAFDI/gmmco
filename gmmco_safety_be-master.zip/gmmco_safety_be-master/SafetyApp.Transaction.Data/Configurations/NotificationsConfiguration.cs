﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class NotificationsConfiguration : IEntityTypeConfiguration<EN_TXN_Notifications>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_Notifications> builder)
        {

            builder.HasKey(table => table.NotificationId);

            builder.HasOne(table => table.User)
                .WithMany()
                .HasForeignKey(table => table.UserId);


        }
    }
}
