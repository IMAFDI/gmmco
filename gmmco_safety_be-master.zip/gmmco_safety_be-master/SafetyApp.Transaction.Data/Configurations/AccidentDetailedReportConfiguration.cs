﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class AccidentDetailedReportConfiguration : IEntityTypeConfiguration<EN_TXN_AccidentDetailedReport>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_AccidentDetailedReport> builder)
        {

            builder.HasKey(table => table.Id);

            //builder.HasOne(table => table.FirstInFormationReport)
            //   .WithMany()
            //   .HasForeignKey(table => table.FirstInFormationReportId);

            builder.Property(table => table.ChronologyOfEvents)
                .HasMaxLength(1000);

        }

    }
}


