﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;
using SafetyApp.Transaction;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class FirstAidReportConfiguration : IEntityTypeConfiguration<EN_TXN_FirstAidReport>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_FirstAidReport> builder)
        {

            builder.HasKey(table => table.ReportId);

            

        }
    }
}
