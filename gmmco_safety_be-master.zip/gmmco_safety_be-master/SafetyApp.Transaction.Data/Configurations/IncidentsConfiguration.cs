﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class IncidentsConfiguration : IEntityTypeConfiguration<EN_TXN_Incidents>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_Incidents> builder)
        {

            builder.HasKey(table => table.IncidentId);
        }
    }
}
