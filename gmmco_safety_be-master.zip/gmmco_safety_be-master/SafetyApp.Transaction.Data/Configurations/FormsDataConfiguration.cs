﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;
using SafetyApp.Transaction;

namespace SafetyApp.Transaction.Data.Configurations
{ 
    public class FormsDataConfiguration : IEntityTypeConfiguration<EN_TXN_FormsData>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_FormsData> builder)
        {

            builder.HasKey(table => table.Id);

            builder.HasOne(table => table.FormType)
                .WithMany()
                .HasForeignKey(table => table.FormTypeId);
        }
    }
}
