﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace SafetyApp.Transaction.Data.Configurations
{
    public class NearMissReportConfiguration : IEntityTypeConfiguration<EN_TXN_NearMissReport>
    {
        public void Configure(EntityTypeBuilder<EN_TXN_NearMissReport> builder)
        {

            builder.HasKey(table => table.ReportId);


            builder.HasOne(table => table.Location)
                .WithMany()
                .HasForeignKey(table => table.LocationId);

            builder.HasOne(table => table.Workstation)
                .WithMany()
                .HasForeignKey(table => table.WorkstationId);
        }
    }
}
