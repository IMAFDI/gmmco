﻿using SafetyApp.Core.Data;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Transaction.Data.Repositories;

public class IncidentRepository : GenericRepository<Guid, EN_TXN_Incidents>, IIncidentRepository
{
    /// <summary>
    /// Initializes a new instance of the <see cref="StatusRepository" /> class.
    /// </summary>
    /// <param name="dbContext">The database context.</param>
    public IncidentRepository(TransactionDbContext dbContext) : base(dbContext) { }
}
