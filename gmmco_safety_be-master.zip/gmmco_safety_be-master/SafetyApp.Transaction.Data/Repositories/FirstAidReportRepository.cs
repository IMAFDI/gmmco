﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SafetyApp.Core.Data;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Transaction.Data.Repositories
{
    public class FirstAidReportRepository : GenericRepository<Guid , EN_TXN_FirstAidReport>, IFirstAidReportRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FirstAidReportRepository" /> class.
        /// </summary>
        /// <param name="dbContext">The database context.</param>
        public FirstAidReportRepository(TransactionDbContext dbContext) : base(dbContext) { }
    }
}
