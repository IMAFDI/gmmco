﻿using SafetyApp.Core.Data;
using SafetyApp.Transaction;
using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Infrastructure.Persistence.Repositories
{
    public class NearMissReportRepository : GenericRepository<Guid, EN_TXN_NearMissReport>, INearMissReportRepository
    {
        public NearMissReportRepository(TransactionDbContext context) : base(context) { }
    }


}
