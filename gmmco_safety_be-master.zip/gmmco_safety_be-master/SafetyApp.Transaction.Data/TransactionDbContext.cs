﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Master;
using SafetyApp.Transaction.Data.Configurations;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Transaction.Data;

/// <summary>
/// Transaction DB Context.
/// </summary>
[ExcludeFromCodeCoverage]
public class TransactionDbContext : DbContext
{
    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionDbContext"/> class.
    /// </summary>
    public TransactionDbContext() : base() { }

    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionDbContext"/> class.
    /// </summary>
    /// <param name="options">The options.</param>
    public TransactionDbContext(DbContextOptions<TransactionDbContext> options) : base(options) { }


    public DbSet<EN_TXN_AccidentDetailedReport> TB_TXN_AccidentDetailedReport { get; set; }
    public DbSet<EN_TXN_FirstAidReport> TB_TXN_FirstAidReport { get; set; }
    public DbSet<EN_TXN_FirstInFormationReport> TB_TXN_FirstInFormationReport { get; set; }
    public DbSet<EN_TXN_FormsData> TB_TXN_FormsData { get; set; }
    public DbSet<EN_TXN_FRIInjuredPeople> TB_TXN_FRIInjuredPeople { get; set; }
    public DbSet<EN_TXN_IncidentAttachment> TB_TXN_IncidentAttachment { get; set; }
    public DbSet<EN_TXN_Incidents> TB_EN_TXN_Incidents { get; set; }
    public DbSet<EN_TXN_NearMissReport> TB_EN_TXN_NearMissReports { get; set; }
    public DbSet<EN_TXN_Notifications> TB_TXN_Notifications { get; set; }
    public DbSet<EN_TXN_PermitToWork> TB_TXN_PermitToWork { get; set; }


    /// <summary>
    /// Gets the database context.
    /// </summary>
    /// <value>
    /// The database context.
    /// </value>
    public DbContext DbContext { get => this; }

    /// <summary>
    /// Persist all changes into persistence as single operation.
    /// </summary>
    /// <returns>
    /// Number of record that changed.
    /// </returns>
    public override int SaveChanges()
    {
        bool saveFailed;
        int recordChanges = 0;

        do
        {
            saveFailed = false;

            try
            {
                recordChanges = base.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                saveFailed = true;

                // Update the values of the entity that failed to save from the store 
                ex.Entries.Single().Reload();
            }
        }
        while (saveFailed);

        return recordChanges;
    }

    /// <summary>
    /// Obtain DBSet for given entity type.
    /// </summary>
    /// <typeparam name="TEntity">The type of the entity.</typeparam>
    /// <returns>
    /// DBSet for given entity type.
    /// </returns>
    public DbSet<TEntity> GetEntitySet<TEntity>() where TEntity : class
    {
        return Set<TEntity>();
    }

    /// <summary>
    /// This method is called when the model for a derived context has been initialized, but
    /// before the model has been locked down and used to initialize the context.  The default
    /// implementation of this method does nothing, but it can be overridden in a derived class
    /// such that the model can be further configured before it is locked down.
    /// </summary>
    /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
    /// <remarks>
    /// Typically, this method is called only once when the first instance of a derived context
    /// is created.  The model for that context is then cached and is for all further instances of
    /// the context in the app domain.  This caching can be disabled by setting the ModelCaching
    /// property on the given ModelBuilder, but note that this can seriously degrade performance.
    /// More control over caching is provided through use of the DBModelBuilder and DBContextFactory
    /// classes directly.
    /// </remarks>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("FN_SAFETYAPP_TXN");
        base.OnModelCreating(modelBuilder);

        if (modelBuilder != null)
        {


            modelBuilder.ApplyConfiguration(new AccidentDetailedReportConfiguration());
            modelBuilder.ApplyConfiguration(new FirstAidReportConfiguration());
            modelBuilder.ApplyConfiguration(new FirstInFormationReportConfiguration());
            modelBuilder.ApplyConfiguration(new FormsDataConfiguration());
            modelBuilder.ApplyConfiguration(new FRIInjuredPeopleConfiguration());
            modelBuilder.ApplyConfiguration(new IncidentAttachmentConfiguration());
            modelBuilder.ApplyConfiguration(new IncidentsConfiguration());
            modelBuilder.ApplyConfiguration(new NearMissReportConfiguration());
            modelBuilder.ApplyConfiguration(new NotificationsConfiguration());
            modelBuilder.ApplyConfiguration(new PermitToWorkConfiguration());

            modelBuilder.Ignore<EN_MSTR_Employee>();

        }
    }
}
