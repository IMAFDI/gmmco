﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data;
using SafetyApp.Transaction.Data.Interface;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Transaction.Data;

/// <summary>
/// Implementation of Unit of Work Pattern.
/// </summary>
/// <typeparam name="T">Dynamic parameter.</typeparam>
public class TransactionUnitOfWork<T> : UnitOfWork<T>, ITransactionUnitOfWork<T> where T : DbContext
{


    /// <summary>
    /// Initializes a new instance of the <see cref="TransactionUnitOfWork{T}" /> class.
    /// </summary>
    /// <param name="dbContext">The database context.</param>
    /// <param name="accessRequestRepository">The access request repository.</param>
    /// <param name="accessRequestUploadRepository">The access request upload repository.</param>
    /// <param name="accessRequestRemarkRepository">The access request remark repository.</param>
    /// <param name="reconRoleRepository">The recon role repository.</param>
    /// <param name="reconAccountRepository">The recon account repository.</param>
    /// <param name="emailQueueRepository">The email queue repository.</param>
    /// <param name="emailDetailsRepository">The email details repository.</param>
    /// <param name="emailAttachmentRepository">The email attachment repository.</param>


    public INearMissReportRepository NearMissReportRepository { get; set; }
    public IFirstAidReportRepository FirstAidReportRepository { get; set; }
    public IIncidentRepository IncidentsRepository { get; set; }

    public TransactionUnitOfWork(TransactionDbContext dbContext,
         INearMissReportRepository nearMissReportRepository,
         IFirstAidReportRepository firstAidReportRepository,
         IIncidentRepository incidentsRepository

        ) : base(dbContext)
    {
        _dbContext = dbContext;

        NearMissReportRepository = nearMissReportRepository;
        FirstAidReportRepository = firstAidReportRepository;
        IncidentsRepository = incidentsRepository;

    }
}

