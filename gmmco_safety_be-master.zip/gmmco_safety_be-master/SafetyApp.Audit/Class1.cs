﻿namespace SafetyApp.Audit
{
    public class Class1
    {

    }
}
