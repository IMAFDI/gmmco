﻿namespace SafetyApp.DynamicFormBuilder.Service
{
    public class Class1
    {

    }
}
