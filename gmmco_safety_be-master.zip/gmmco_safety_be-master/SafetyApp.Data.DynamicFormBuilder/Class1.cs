﻿namespace SafetyApp.Data.DynamicFormBuilder
{
    public class Class1
    {

    }
}
