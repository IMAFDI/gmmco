﻿using AutoMapper;
using SafetyApp.Presentation.Shared.Models;
using SafetyApp.Transaction;

namespace SafetyApp.Presentation.Shared.MappingProfiles;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
        #region Audit



        #endregion

        #region Master


        #endregion

        #region Transaction
        CreateMap<EN_TXN_NearMissReport, NearMissReportModel>()
               .ForMember(dest => dest.LocationName,
                          opt => opt.MapFrom(src => src.Location != null ? src.Location.LocationName : string.Empty))
               .ForMember(dest => dest.WorkstationName,
                          opt => opt.MapFrom(src => src.Workstation != null ? src.Workstation.WorkstationName : string.Empty));


        CreateMap<NearMissReportModel, EN_TXN_NearMissReport>()
            .ForMember(dest => dest.Location, opt => opt.Ignore())
            .ForMember(dest => dest.Workstation, opt => opt.Ignore());

        CreateMap<EN_TXN_FirstAidReport, FirstAidReportModel>().ReverseMap();

        #endregion



    }
}
