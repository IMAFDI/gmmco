﻿namespace SafetyApp.Presentation.Shared
{
    public class Class1
    {

    }
}
