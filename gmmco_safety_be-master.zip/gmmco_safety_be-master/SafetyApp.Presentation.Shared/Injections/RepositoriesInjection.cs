﻿using Microsoft.Extensions.DependencyInjection;
using SafetyApp.Audit.Data;
using SafetyApp.Audit.Data.Interface;
using SafetyApp.Infrastructure.Persistence.Repositories;
using SafetyApp.Master.Data;
using SafetyApp.Master.Data.Interface;
using SafetyApp.Master.Data.Repositories;
using SafetyApp.Transaction.Data;
using SafetyApp.Transaction.Data.Interface;
using SafetyApp.Transaction.Data.Repositories;
using SafetyApp.Transaction.Repositories;

namespace SafetyApp.Presentation.Shared.Injections;

public static class RepositoriesInjection
{
    public static IServiceCollection AddApplicationRepositories(this IServiceCollection services)
    {
        #region Audit

        //services.AddScoped<ILogRepository, LogRepository>();


        services.AddScoped<IAuditUnitOfWork<AuditDbContext>, AuditUnitOfWork<AuditDbContext>>();

        #endregion

        #region Master

        services.AddScoped<IEmployeeRepository, EmployeeRepository>();


        services.AddScoped<IMasterUnitOfWork<MasterDbContext>, MasterUnitOfWork<MasterDbContext>>();

        #endregion

        #region Transaction

        //services.AddScoped<IEmailQueueRepository, EmailQueueRepository>();
        services.AddScoped<INearMissReportRepository, NearMissReportRepository>();
        services.AddScoped<IFirstAidReportRepository, FirstAidReportRepository>();
        services.AddScoped<IIncidentRepository, IncidentRepository>();

        services.AddScoped<ITransactionUnitOfWork<TransactionDbContext>, TransactionUnitOfWork<TransactionDbContext>>();



        #endregion


        return services;
    }
}
