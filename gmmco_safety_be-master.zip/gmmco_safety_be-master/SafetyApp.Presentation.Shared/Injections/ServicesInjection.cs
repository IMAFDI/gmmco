﻿using Microsoft.Extensions.DependencyInjection;
using SafetyApp.Master.Service;
using SafetyApp.Master.Service.Interface;
using SafetyApp.Transaction.Service;
using SafetyApp.Transaction.Service.Interface;


namespace SafetyApp.Presentation.Shared.Injections;

public static class ServicesInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        #region Audit

        #endregion

        #region DynamicFormBuilder

        #endregion

        #region Master

        services.AddScoped<IEmployeeService, EmployeeService>();

        #endregion

        #region Transaction

        services.AddScoped<INearMissReportService, NearMissReportService>();
        services.AddScoped<IFirstAidReportService, FirstAidReportService>();
        services.AddScoped<IIncidentService, IncidentService>();

        #endregion

        return services;
    }
}
