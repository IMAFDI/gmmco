﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;
using SafetyApp.Master.Data.Repositories;

namespace SafetyApp.Master.Data.Interface;

/// <summary>
/// Interface for Master Unit Of Work.
/// </summary>
/// <typeparam name="T">Type parameter.</typeparam>
public interface IMasterUnitOfWork<T> : IUnitOfWork<T> where T : DbContext
{
    IEmployeeRepository EmployeeRepository { get; set; }
}
