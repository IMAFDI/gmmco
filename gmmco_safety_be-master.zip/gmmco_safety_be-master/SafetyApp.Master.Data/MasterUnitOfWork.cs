﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data;
using SafetyApp.Master.Data.Interface;
using SafetyApp.Master.Data.Repositories;

namespace SafetyApp.Master.Data;

/// <summary>
/// Implementation of Unit of Work Pattern.
/// </summary>
/// <typeparam name="T">Dynamic parameter.</typeparam>
public class MasterUnitOfWork<T> : UnitOfWork<T>, IMasterUnitOfWork<T> where T : DbContext
{

    /// <summary>
    /// Initializes a new instance of the <see cref="MasterUnitOfWork{T}" /> class.
    /// </summary>
    /// <param name="dbContext">The database context.</param>
    /// 
    public IEmployeeRepository EmployeeRepository { get; set; }

    public MasterUnitOfWork(MasterDbContext dbContext,
        IEmployeeRepository employeeRepository


        ) : base(dbContext)
    {
        _dbContext = dbContext;

        EmployeeRepository = employeeRepository;

    }
}
