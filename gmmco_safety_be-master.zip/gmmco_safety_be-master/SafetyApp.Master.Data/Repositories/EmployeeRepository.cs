﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SafetyApp.Core;
using SafetyApp.Core.Data;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;


namespace SafetyApp.Master.Data.Repositories
{
    public class EmployeeRepository : GenericRepository<int, EN_MSTR_Employee>, IEmployeeRepository
    {
        private readonly MasterDbContext _context;
        private readonly IConfiguration _config;
        private readonly HttpClient _http;


        public EmployeeRepository(
            MasterDbContext dbContext,
            HttpClient http,
            IConfiguration config)
            : base(dbContext)
        {
            _context = dbContext;
            _config = config;
            _http = http;
        }

        public async Task InsertOrIgnoreAsync(IEnumerable<EN_MSTR_Employee> employees, CancellationToken ct = default)
        {
            foreach (var emp in employees)
            {
                bool exists = await _context.TB_MSTR_Employee.AnyAsync(e => e.EmployeeId == emp.EmployeeId, ct);

                if (!exists)
                {
                    await _context.TB_MSTR_Employee.AddAsync(emp, ct);
                }
            }

            await _context.SaveChangesAsync(ct);
        }

        public async Task<List<EN_MSTR_Employee>> GetAllEmployeesAsync(CancellationToken ct = default)
        {
            return await _context.TB_MSTR_Employee.ToListAsync(ct);
        }

        public async Task<EN_MSTR_Employee[]> FetchEmployeesAsync(CancellationToken ct = default)
        {
            var section = _config.GetSection(Constants.ConfigurationSections.DARWINBOXCLIENTSERVICE_CONFIG);

            var apiUrl = section[Constants.ConfigurationKeys.API_URL];
            var username = section[Constants.ConfigurationKeys.USERNAME];
            var password = section[Constants.ConfigurationKeys.PASSWORD];
            var apiKey = section[Constants.ConfigurationKeys.API_KEY];
            var datasetKey = section[Constants.ConfigurationKeys.DATASET_KEY];

            if (string.IsNullOrWhiteSpace(apiUrl) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(apiKey) ||
                string.IsNullOrWhiteSpace(datasetKey))
            {
                throw new InvalidOperationException("DarwinBox API configuration is missing or invalid.");
            }

            var bytes = Encoding.ASCII.GetBytes($"{username}:{password}");
            _http.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Basic", Convert.ToBase64String(bytes));
            _http.DefaultRequestHeaders.Accept.Clear();
            _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var body = new
            {
                api_key = apiKey,
                datasetKey = datasetKey
            };

            using var content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
            using var req = new HttpRequestMessage(HttpMethod.Post, apiUrl) { Content = content };
            using var resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);

            if (!resp.IsSuccessStatusCode)
            {
                var err = await resp.Content.ReadAsStringAsync(ct);
                throw new InvalidOperationException($"DarwinBox API failed: {(int)resp.StatusCode} {resp.ReasonPhrase}. Body: {err}");
            }

            var json = await resp.Content.ReadAsStringAsync(ct);

            using var doc = JsonDocument.Parse(json);
            var employees = doc.RootElement
                .GetProperty("employee_data")
                .Deserialize<EN_MSTR_Employee[]>(new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowReadingFromString
                });

            return employees ?? Array.Empty<EN_MSTR_Employee>();
        }
    }

}

