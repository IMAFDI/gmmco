﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SafetyApp.Configurations;
using SafetyApp.Master.Data.Configurations;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Master.Data;

/// <summary>
/// Master DB Context.
/// </summary>
[ExcludeFromCodeCoverage]
public class MasterDbContext :
    IdentityDbContext<EN_MSTR_User, EN_MSTR_Role, int, IdentityUserClaim<int>, EN_MSTR_UserRole, IdentityUserLogin<int>, IdentityRoleClaim<int>, IdentityUserToken<int>>
{
    /// <summary>
    /// Initializes a new instance of the <see cref="MasterDbContext"/> class.
    /// </summary>
    public MasterDbContext() : base() { }

    /// <summary>
    /// Initializes a new instance of the <see cref="MasterDbContext"/> class.
    /// </summary>
    /// <param name="options">The options.</param>
    public MasterDbContext(DbContextOptions<MasterDbContext> options) : base(options) { }

    public DbSet<EN_MSTR_Employee> TB_MSTR_Employee { get; set; }
    public DbSet<EN_MSTR_FormType> TB_MSTR_FormType { get; set; }
    public DbSet<EN_MSTR_IncidentType> TB_MSTR_IncidentType { get; set; }
    public DbSet<EN_MSTR_Location> TB_MSTR_Location { get; set; }
    public DbSet<EN_MSTR_PermitType> TB_MSTR_PermitType { get; set; }
    public DbSet<EN_MSTR_Role> TB_MSTR_Role { get; set; }
    public DbSet<EN_MSTR_User> TB_MSTR_User { get; set; }
    public DbSet<EN_MSTR_UserRole> TB_MSTR_UserRole { get; set; }
    public DbSet<EN_MSTR_Workstation> TB_MSTR_Workstation { get; set; }


    /// <summary>
    /// Gets the database context.
    /// </summary>
    /// <value>
    /// The database context.
    /// </value>
    public DbContext DbContext { get => this; }

    /// <summary>
    /// Persist all changes into persistence as single operation.
    /// </summary>
    /// <returns>
    /// Number of record that changed.
    /// </returns>
    public override int SaveChanges()
    {
        bool saveFailed;
        int recordChanges = 0;

        do
        {
            saveFailed = false;

            try
            {
                recordChanges = base.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                saveFailed = true;

                // Update the values of the entity that failed to save from the store 
                ex.Entries.Single().Reload();
            }
        }
        while (saveFailed);

        return recordChanges;
    }

    /// <summary>
    /// Obtain DBSet for given entity type.
    /// </summary>
    /// <typeparam name="TEntity">The type of the entity.</typeparam>
    /// <returns>
    /// DBSet for given entity type.
    /// </returns>
    public DbSet<TEntity> GetEntitySet<TEntity>() where TEntity : class
    {
        return Set<TEntity>();
    }

    /// <summary>
    /// This method is called when the model for a derived context has been initialized, but
    /// before the model has been locked down and used to initialize the context.  The default
    /// implementation of this method does nothing, but it can be overridden in a derived class
    /// such that the model can be further configured before it is locked down.
    /// </summary>
    /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
    /// <remarks>
    /// Typically, this method is called only once when the first instance of a derived context
    /// is created.  The model for that context is then cached and is for all further instances of
    /// the context in the app domain.  This caching can be disabled by setting the ModelCaching
    /// property on the given ModelBuilder, but note that this can seriously degrade performance.
    /// More control over caching is provided through use of the DBModelBuilder and DBContextFactory
    /// classes directly.
    /// </remarks>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("FN_SAFETYAPP_MASTER");
        base.OnModelCreating(modelBuilder);

        if (modelBuilder != null)
        {
            modelBuilder.ApplyConfiguration(new EmployeeConfiguration());
            modelBuilder.ApplyConfiguration(new FormTypeConfiguration());
            modelBuilder.ApplyConfiguration(new IncidentTypeConfiguration());
            modelBuilder.ApplyConfiguration(new LocationConfiguration());
            modelBuilder.ApplyConfiguration(new PermitTypeConfiguration());
            modelBuilder.ApplyConfiguration(new RoleConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
            modelBuilder.ApplyConfiguration(new UserRoleConfiguration());
            modelBuilder.ApplyConfiguration(new WorkstationConfiguration());
        }
    }

}
