﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SafetyApp.Master;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Configurations
{
    [ExcludeFromCodeCoverage]
    public class RoleConfiguration : IEntityTypeConfiguration<EN_MSTR_Role>
    {
        public void Configure(EntityTypeBuilder<EN_MSTR_Role> builder)
        {
            builder.HasKey(table => table.ROLE_ID);

            builder.HasMany<EN_MSTR_UserRole>()
                   .WithOne()
                   .HasForeignKey(table => table.ROLE_ID);
        }
    }
}
