﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Master.Data.Configurations;

[ExcludeFromCodeCoverage]
public class PermitTypeConfiguration : IEntityTypeConfiguration<EN_MSTR_PermitType>
{
    public void Configure(EntityTypeBuilder<EN_MSTR_PermitType> builder)
    {
        builder.HasKey(table => table.Id);

    }
}
