﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Master.Data.Configurations;

[ExcludeFromCodeCoverage]
public class WorkstationConfiguration : IEntityTypeConfiguration<EN_MSTR_Workstation>
{
    public void Configure(EntityTypeBuilder<EN_MSTR_Workstation> builder)
    {

        builder.HasKey(table => table.Id);
        builder.Property(table => table.WorkstationName)
            .HasMaxLength(150)
            .IsRequired();
        builder.Property(table => table.WorkstationCode)
            .HasMaxLength(50)
            .IsRequired();
        builder.Property(table => table.RECORD_SOURCE_NAME)
            .HasMaxLength(100)
            .IsFixedLength(false);


    }
}
