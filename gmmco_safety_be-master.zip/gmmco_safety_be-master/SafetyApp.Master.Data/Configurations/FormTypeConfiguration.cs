﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Master.Data.Configurations;

[ExcludeFromCodeCoverage]
public class FormTypeConfiguration : IEntityTypeConfiguration<EN_MSTR_FormType>
{
    public void Configure(EntityTypeBuilder<EN_MSTR_FormType> builder)
    {
        builder.HasKey(table => table.Id);

    }
}
