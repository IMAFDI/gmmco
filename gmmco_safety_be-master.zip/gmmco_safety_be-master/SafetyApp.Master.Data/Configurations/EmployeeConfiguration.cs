﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Master.Data.Configurations;

[ExcludeFromCodeCoverage]
public class EmployeeConfiguration : IEntityTypeConfiguration<EN_MSTR_Employee>
{
    public void Configure(EntityTypeBuilder<EN_MSTR_Employee> builder)
    {
        builder.HasKey(table => table.EmployeeId);

        builder.HasOne<EN_MSTR_User>()
               .WithOne()
               .HasForeignKey<EN_MSTR_User>(table => table.EmployeeId);
    }
}