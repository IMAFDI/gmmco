﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_IncidentType : EntityBase
    {
        public int Id { get; set; }
        public string IncidentTypeName { get; set; }
        public string IncidentTypeCode { get; set; }

    }
}
