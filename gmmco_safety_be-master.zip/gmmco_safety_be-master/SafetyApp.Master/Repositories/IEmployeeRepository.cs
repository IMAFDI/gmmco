﻿using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Master.Data.Repositories;

public interface IEmployeeRepository : IGenericRepository<int, EN_MSTR_Employee>
{
    Task InsertOrIgnoreAsync(IEnumerable<EN_MSTR_Employee> employees, CancellationToken ct = default);
    Task<List<EN_MSTR_Employee>> GetAllEmployeesAsync(CancellationToken ct = default);
    Task<EN_MSTR_Employee[]> FetchEmployeesAsync(CancellationToken ct = default);
}
