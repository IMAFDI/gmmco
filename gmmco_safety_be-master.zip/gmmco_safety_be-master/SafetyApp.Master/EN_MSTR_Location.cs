﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_Location : EntityBase
    {
        public int Id { get; set; }
        public string LocationName { get; set; }
        public string LocationCode { get; set; }

    }
}
