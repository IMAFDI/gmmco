﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_FormType : EntityBase
    {
        public int Id { get; set; }
        public string FormTypeName { get; set; }
        public string FormTypeCode { get; set; }

    }
}
