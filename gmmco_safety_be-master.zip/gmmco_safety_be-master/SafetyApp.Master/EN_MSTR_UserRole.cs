﻿using Microsoft.AspNetCore.Identity;

namespace SafetyApp.Master
{
    public class EN_MSTR_UserRole : IdentityUserRole<int>
    {
        public int USER_ROLE_ID { get; set; }
        public int USER_ID { get; set; }
        public int ROLE_ID { get; set; }
        public int? CREATED_ID { get; set; }
        public DateTime CREATED_DATE { get; set; }
        public int? UPDATED_ID { get; set; }
        public DateTime? UPDATED_DATE { get; set; }
        public bool IS_ACTIVE { get; set; }
        public DateTime? DELETED_AT { get; set; }
        public int? DELETED_BY { get; set; }
        public string? RECORD_SOURCE_NAME { get; set; }
    }
}
