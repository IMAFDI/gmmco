﻿using Microsoft.AspNetCore.Identity;

namespace SafetyApp.Master
{
    public class EN_MSTR_Role : IdentityRole<int>
    {
        public int ROLE_ID { get; set; }
        public string ROLE_NAME { get; set; }
        public int? CREATED_ID { get; set; }
        public DateTime CREATED_DATE { get; set; }
        public int? UPDATED_ID { get; set; }
        public DateTime? UPDATED_DATE { get; set; }
        public bool IS_ACTIVE { get; set; }
        public DateTime? DELETED_AT { get; set; }
        public int? DELETED_BY { get; set; }
        public string? RECORD_SOURCE_NAME { get; set; }
    }
}
