﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_Employee : EntityBase
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateOnly DateOfJoining { get; set; }
        public string ContributionLevel { get; set; }
        public string DirectManager { get; set; }
        public string DirectManagerEmail { get; set; }
        public int DirectManagerEmployeeId { get; set; }
        public string Division { get; set; }
        public string SubEmployeeType { get; set; }
        public bool EmployeeStatus { get; set; }
        public int EmployeeType { get; set; }
        public string JobLevel { get; set; }
        public string PsGroup { get; set; }
        public string PsLevel { get; set; }
        public string SBU { get; set; }
        public DateOnly DateOfBirth { get; set; }
        public string CompanyEmailId { get; set; }
        public string Gender { get; set; }
        public string OfficeCity { get; set; }
        public string OfficeLocation { get; set; }
        public string OfficeRegion { get; set; }
        public string OfficeState { get; set; }
        public string OfficeMobileNo { get; set; }
        public int GmmcoDept { get; set; }
        public int SafetyRole { get; set; }

    }
}
