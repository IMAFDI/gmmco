﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_Workstation : EntityBase
    {
        public int Id { get; set; }
        public string WorkstationName { get; set; }
        public string WorkstationCode { get; set; }

    }
}
