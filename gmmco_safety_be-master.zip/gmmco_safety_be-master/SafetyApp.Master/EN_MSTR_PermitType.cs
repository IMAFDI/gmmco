﻿using SafetyApp.Core;

namespace SafetyApp.Master
{
    public class EN_MSTR_PermitType : EntityBase
    {
        public int Id { get; set; }
        public string PermitTypeName { get; set; }
        public string PermitTypeCode { get; set; }

    }
}
