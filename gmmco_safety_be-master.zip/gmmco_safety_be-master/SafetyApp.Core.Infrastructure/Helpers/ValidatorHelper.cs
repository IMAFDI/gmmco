﻿namespace SafetyApp.Core.Infrastructure.Helpers;

public static class ValidatorHelper
{

    //public static DomainException CreateDomainException(ValidationResult validationResult)
    //{
    //    if (validationResult == null)
    //    {
    //        throw new ArgumentNullException("validationResult");
    //    }

    //    var messages = validationResult.Errors
    //        .Select(result => new Message
    //        {
    //            FieldName = result.PropertyName,
    //            MessageType = MessageType.Error,
    //            Value = result.ErrorMessage
    //        });

    //    return new DomainException(messages);
    //}
}
