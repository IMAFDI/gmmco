﻿namespace SafetyApp.Core.Infrastructure;

public class Request<TModel>
{
    public TModel Model { get; set; }
}
