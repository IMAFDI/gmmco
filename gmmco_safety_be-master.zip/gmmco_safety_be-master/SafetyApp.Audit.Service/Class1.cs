﻿namespace SafetyApp.Audit.Service
{
    public class Class1
    {

    }
}
