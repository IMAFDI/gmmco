﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_TRNSTN_FormFieldValues : EntityBase
    {
        public int Id { get; set; }
        public int FieldId { get; set; }
        public string FieldValue { get; set; }
        public string FieldRemarks { get; set; }

    }
}
