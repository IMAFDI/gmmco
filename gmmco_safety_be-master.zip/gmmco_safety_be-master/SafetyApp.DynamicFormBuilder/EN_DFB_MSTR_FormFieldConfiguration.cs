﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder;

public class EN_DFB_MSTR_FormFieldConfiguration : EntityBase
{
    public int Id { get; set; }
    public int SectionId { get; set; }
    public int SubSectionId { get; set; }
    public int FieldTypeId { get; set; }
    public string FieldDescription { get; set; }
    public bool IsRemarksMandatory { get; set; }
    public bool IsAttribute { get; set; }
    public int AttributeId { get; set; }
    public string FieldOptions { get; set; }
    public int FieldSequence { get; set; }
    public string FieldImage1 { get; set; }
    public string FieldImage2 { get; set; }
    public string FieldImage3 { get; set; }
    public string FieldImage4 { get; set; }
    public string FieldImage5 { get; set; }

}
