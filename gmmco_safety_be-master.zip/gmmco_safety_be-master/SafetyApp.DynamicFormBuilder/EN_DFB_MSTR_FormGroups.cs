﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_MSTR_FormGroups : EntityBase
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public string GroupDesc { get; set; }

    }
}
