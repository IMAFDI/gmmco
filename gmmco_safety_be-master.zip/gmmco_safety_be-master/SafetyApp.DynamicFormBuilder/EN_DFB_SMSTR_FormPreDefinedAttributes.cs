﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_SMSTR_FormPreDefinedAttributes : EntityBase
    {
        public int Id { get; set; }
        public string FieldType { get; set; }
        public string FieldName { get; set; }

    }
}
