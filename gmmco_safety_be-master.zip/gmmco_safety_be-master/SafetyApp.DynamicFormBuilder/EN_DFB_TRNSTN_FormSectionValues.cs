﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_TRNSTN_FormSectionValues : EntityBase
    {
        public int Id { get; set; }
        public int SectionId { get; set; }
        public int SubSectionId { get; set; }
        public string RemarksValue { get; set; }

    }
}
