﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class DFB_SMSTR_FormFieldType : EntityBase
    {
        public int Id { get; set; }
        public string FieldType { get; set; }

    }
}
