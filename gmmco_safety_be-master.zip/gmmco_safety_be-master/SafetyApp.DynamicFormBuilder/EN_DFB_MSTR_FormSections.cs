﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_MSTR_FormSections : EntityBase
    {
        public int Id { get; set; }
        public int FormId { get; set; }
        public string SectionName { get; set; }
        public string SectionDesc { get; set; }
        public string SectionImage { get; set; }
        public int SectionSequence { get; set; }
        public bool IsRemarksAvailable { get; set; }
        public string RemarksLabel { get; set; }

    }
}
