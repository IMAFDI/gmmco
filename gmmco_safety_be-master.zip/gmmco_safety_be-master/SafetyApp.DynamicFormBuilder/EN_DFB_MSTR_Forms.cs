﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_MSTR_Forms : EntityBase
    {
        public int Id { get; set; }
        public int GroupId { get; set; }
        public string FormName { get; set; }
        public string FormCode { get; set; }
        public string FormDesc { get; set; }
        public string DocumentNumber { get; set; }
        public string RevisionNumber { get; set; }
        public DateOnly RevisionDate { get; set; }
        public int FormStatus { get; set; }
        public string FormImage { get; set; }
        public string FormLogo { get; set; }

    }
}
