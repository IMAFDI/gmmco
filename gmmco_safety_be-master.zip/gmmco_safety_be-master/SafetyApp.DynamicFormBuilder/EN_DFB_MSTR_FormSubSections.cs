﻿using SafetyApp.Core;

namespace SafetyApp.DynamicFormBuilder
{
    public class EN_DFB_MSTR_FormSubSections : EntityBase
    {
        public int Id { get; set; }
        public int SectionId { get; set; }
        public string SubSectionName { get; set; }
        public string SubSectionDesc { get; set; }
        public string SubSectionImage { get; set; }
        public int SubSectionSequence { get; set; }
        public bool IsRemarksAvailable { get; set; }
        public string RemarksLabel { get; set; }

    }
}
