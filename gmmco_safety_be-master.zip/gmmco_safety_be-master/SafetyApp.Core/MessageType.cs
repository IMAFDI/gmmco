﻿namespace SafetyApp.Core;

public enum MessageType
{
    Success,
    Information,
    Warning,
    Error
}
