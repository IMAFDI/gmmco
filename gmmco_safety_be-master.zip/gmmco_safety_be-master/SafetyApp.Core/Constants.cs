﻿namespace SafetyApp.Core;

public static class Constants
{
    public static class Common
    {
        public static readonly string SAFETYAPP_MIGRATION_ASSEMBLY = "SafetyApp.Data.Security";
        public static readonly string SAFETYAPP_LOG_MIGRATION_ASSEMBLY = "SafetyApp.Data.Log";
        public static readonly string SAFETYAPP_TRANSACTION_MIGRATION_ASSEMBLY = "SafetyApp.Data.Transaction";
        public static readonly string FORMAT_APPLICATION_JSON = "application/json";
        public static readonly string WEB_API_CLIENT = "webApiClient";
        public static readonly string AUTH_TOKEN = "authToken";
        public static readonly string AUTH_HEADER_BEARER = "bearer";

    }

    public static class ConfigurationSections
    {
        public static readonly string GENERAL_CONFIG = "GeneralConfig";
        public static readonly string IDENTITY_CONFIG = "IdentityConfig";
        public static readonly string EMAIL_CONFIG = "EmailConfig";
        public static readonly string FILE_CONFIG = "FileConfig";
        public static readonly string AUTH_CONFIG = "AuthConfig";
        public static readonly string DARWINBOXCLIENTSERVICE_CONFIG = "DarwinBoxClientServiceConfig";
    }

    public static class ConfigurationKeys
    {
        public static readonly string CONNECTION_STRING = "SecurityDbContextConnection";


        #region General



        #endregion

        #region Identity

        public static readonly string JWT_ISSUER = "JwtIssuer";
        public static readonly string JWT_AUDIENCE = "JwtAudience";
        public static readonly string JWT_SECURITY_KEY = "JwtSecurityKey";
        public static readonly string JWT_EXPIRY_IN_DAYS = "JwtExpiryInDays";
        public static readonly string JWT_EXPIRY_IN_MINUTES = "JtExwpiryInMinutes";
        public static readonly string JWT_EXPIRY_IN_HOURS = "JwtExpiryInHours";

        #endregion

        #region Email

        public static readonly string SMTP_FROM_ADDRESS = "SmtpFromAddress";
        public static readonly string SMTP_HOST = "SmtpHost";
        public static readonly string SMTP_PORT = "SmtpPort";
        public static readonly string SMTP_USERNAME = "SmtpUsername";
        public static readonly string SMTP_PASSWORD = "SmtpPassword";

        #endregion

        #region File



        #endregion

        #region Auth
        
        public static readonly string API_KEY = "ApiKey";
        public static readonly string DATASET_KEY = "DataSetKey";
        #endregion

        #region DarwinBoxClientService
        public static readonly string API_URL = "ApiUrl";
        public static readonly string USERNAME = "Username";
        public static readonly string PASSWORD = "Password";
        public static readonly string DARWINBOX_API_KEY = "ApiKey";
        public static readonly string DARWINBOX_DATASET_KEY = "DatasetKey";
        #endregion


    }

    public static class WebAPIEndpoints
    {
        public static readonly string MENUS_FIND_ALL = "api/Menus";
        public static readonly string ROLES_FIND_ALL = "api/Roles";
        public static readonly string USERS_FIND_ALL = "api/Users";
        public static readonly string ACCOUNTS_REGISTRATION = "api/Accounts";
        public static readonly string LOGIN_LOGIN = "api/Login";
        public static readonly string APPLICATION_TYPES_FIND_ALL = "api/ApplicationTypes";
        public static readonly string APPLICATIONS_FIND_ALL = "api/Applications";
        public static readonly string APPLICATION_ROLES_FIND_ALL = "api/ApplicationRoles";
        public static readonly string WEATHER_FORECAST = "WeatherForecast";
        public static readonly string LOGS_FIND_ALL = "api/Logs";
        public static readonly string STATUSES_FIND_ALL = "api/Status";
    }

    public static class DatastubConstants
    {
        public static readonly string RECORD_SOURCE_NAME_SAFETYAPP_APPLICATION_API = "SafetyApp Application API";
        public static readonly string RECORD_SOURCE_NAME_SAFETYAPP_AUTHSERVICE_API = "SafetyApp AuthService API";
        public static readonly string RECORD_SOURCE_NAME_SAFETYAPP_NOTIFICATION_API = "SafetyApp Notification API";

    }

    public static class ApplicationMessages
    {
        public static readonly string ERROR_GENERAL = "Application error. Exception: {0}. Stack trace: {1}";
        public static readonly string ERROR_GENERAL_FRIENDLY = "Application encountered an exception.";
        public static readonly string ERROR_DB_MIGRATION = "Error migrating database. Exception: {exception}. Stack trace: {stacktrace}";
        public static readonly string EMPTY_REQUEST = "Request is empty.";
        public static readonly string BAD_REQUEST = "Invalid request.";
        public static readonly string SUCCESS_CREATED = "{0} is created successfully.";
        public static readonly string SUCCESS_UPDATED = "{0} updated successfully.";
        public static readonly string SUCCESS_DELETED = "Data deleted successfully.";
        public static readonly string SUCCESS_APPROVED = "{0} approved/rejected successfully.";
        public static readonly string SUCCESS_CANCELLED = "Data cancelled successfully.";
        public static readonly string SUCCESS_SEND_EMAIL = "Email sent successfully.";
        public static readonly string FAILED_SEND_EMAIL = "Email sent successfully.";
        public static readonly string INVALID_LOGIN = "Invalid username or password.";
        public static readonly string FAILED_REGISTRATION = "Account already exists, please log in to continue.";
        public static readonly string NOT_EMPTY = "{0} must be entered.";
        public static readonly string EXISTS = "{0} already exists.";
        public static readonly string NOT_EXISTS = "{0} does not exist.";
        public static readonly string MAPPED = "{0} is mapped.";
        public static readonly string EMAIL_NOT_CONFIRMED = "Email not verified.";
        public static readonly string ROLE_NOT_FOUND = "Role not found. Please contact your support team for assistance.";
        public static readonly string EMAIL_VERIFICATION_SUCCESSFUL = "Email Verification Successful for {0}.";
        public static readonly string PASSWORD_CHANGED_SUCCESSFULLY = "Password changed successfully for {0}.";
        public static readonly string DATA_FETCHED_SUCCESSFULLY = "Data fetched successfully for {0}.";
        public static readonly string DATA_NOT_FOUND = "Data not found.";
        public static readonly string FILE_NOT_UPLOADED = "No file uploaded.";
        public static readonly string NO_RECORD_TO_EXPORT = "No Records found to export.";

    }
    
}
