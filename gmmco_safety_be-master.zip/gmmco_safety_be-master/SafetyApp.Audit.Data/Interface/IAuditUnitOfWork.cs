﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Audit.Data.Interface;

/// <summary>
/// Interface for Audit Unit Of Work.
/// </summary>
/// <typeparam name="T">Type parameter.</typeparam>
public interface IAuditUnitOfWork<T> : IUnitOfWork<T> where T : DbContext
{

}

