﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;

namespace SafetyApp.Audit.Data;

/// <summary>
/// Audit DB Context.
/// </summary>
[ExcludeFromCodeCoverage]
public class AuditDbContext : DbContext
{
    /// <summary>
    /// Initializes a new instance of the <see cref="AuditDbContext"/> class.
    /// </summary>
    public AuditDbContext() : base() { }

    /// <summary>
    /// Initializes a new instance of the <see cref="AuditDbContext"/> class.
    /// </summary>
    /// <param name="options">The options.</param>
    public AuditDbContext(DbContextOptions<AuditDbContext> options) : base(options) { }

    /// <summary>
    /// Gets or sets the user roles.
    /// </summary>
    /// <value>
    /// The user roles.
    /// </value>
    //public virtual DbSet<EN_ANNUITY_AUDIT_LOG> TB_ANNUITY_AUDIT_LOG { get; set; }

    /// <summary>
    /// Gets the database context.
    /// </summary>
    /// <value>
    /// The database context.
    /// </value>
    public DbContext DbContext { get => this; }

    /// <summary>
    /// Persist all changes into persistence as single operation.
    /// </summary>
    /// <returns>
    /// Number of record that changed.
    /// </returns>
    public override int SaveChanges()
    {
        bool saveFailed;
        int recordChanges = 0;

        do
        {
            saveFailed = false;

            try
            {
                recordChanges = base.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                saveFailed = true;

                // Update the values of the entity that failed to save from the store 
                ex.Entries.Single().Reload();
            }
        }
        while (saveFailed);

        return recordChanges;
    }

    /// <summary>
    /// Obtain DBSet for given entity type.
    /// </summary>
    /// <typeparam name="TEntity">The type of the entity.</typeparam>
    /// <returns>
    /// DBSet for given entity type.
    /// </returns>
    public DbSet<TEntity> GetEntitySet<TEntity>() where TEntity : class
    {
        return Set<TEntity>();
    }

    /// <summary>
    /// This method is called when the model for a derived context has been initialized, but
    /// before the model has been locked down and used to initialize the context.  The default
    /// implementation of this method does nothing, but it can be overridden in a derived class
    /// such that the model can be further configured before it is locked down.
    /// </summary>
    /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
    /// <remarks>
    /// Typically, this method is called only once when the first instance of a derived context
    /// is created.  The model for that context is then cached and is for all further instances of
    /// the context in the app domain.  This caching can be disabled by setting the ModelCaching
    /// property on the given ModelBuilder, but note that this can seriously degrade performance.
    /// More control over caching is provided through use of the DBModelBuilder and DBContextFactory
    /// classes directly.
    /// </remarks>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("FN_SAFETYAPP_AUDIT");
        base.OnModelCreating(modelBuilder);

        if (modelBuilder != null)
        {
            //modelBuilder.ApplyConfiguration(new LogConfiguration());
        }
    }
}
