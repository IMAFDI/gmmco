﻿using Microsoft.EntityFrameworkCore;
using SafetyApp.Audit.Data.Interface;
using SafetyApp.Core.Data;

namespace SafetyApp.Audit.Data;

/// <summary>
/// Implementation of Unit of Work Pattern.
/// </summary>
/// <typeparam name="T">Dynamic parameter.</typeparam>
public class AuditUnitOfWork<T> : UnitOfWork<T>, IAuditUnitOfWork<T> where T : DbContext
{
    /// <summary>
    /// Gets or sets the log repository.
    /// </summary>
    /// <value>
    /// The log repository.
    /// </value>
    //public ILogRepository LogRepository { get; set; }
    //public IFeesDiscountAuditHistoryRepository FeesDiscountAuditHistoryRepository { get; set; }

    public AuditUnitOfWork(AuditDbContext dbContext

        ) : base(dbContext)
    {
        _dbContext = dbContext;

    }
}