﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SafetyApp.Core;
using SafetyApp.Core.Infrastructure;
using SafetyApp.Presentation.Shared.Models;
using SafetyApp.Transaction;
using SafetyApp.Transaction.Service.Interface;
using System.Globalization;
using System.Net;

namespace SafetyApp.Application.API.Controllers
{
    public class FirstAidReportController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IFirstAidReportService _firstAidReportService;

        public FirstAidReportController(
            IMapper mapper,
            IFirstAidReportService firstAidReportService)
        {
            _mapper = mapper;
            _firstAidReportService = firstAidReportService;
        }

        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost]
        public IActionResult Post([FromBody] Request<FirstAidReportModel> request)
        {
            var response = new Response<FirstAidReportModel> { Model = new FirstAidReportModel() };

            try
            {
                if (request == null)
                    throw new ArgumentException(Constants.ApplicationMessages.EMPTY_REQUEST);

                var data = _mapper.Map<EN_TXN_FirstAidReport>(request.Model);
                var result = _firstAidReportService.CreateStatus(data);

                if (result != null)
                {
                    response.Model = _mapper.Map<FirstAidReportModel>(result);
                    response.Messages.Add(new Message
                    {
                        MessageType = MessageType.Success,
                        Value = string.Format(CultureInfo.InvariantCulture,
                            Constants.ApplicationMessages.SUCCESS_CREATED,
                            result.ReportId)
                    });
                    return Ok(response);
                }

                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = Constants.ApplicationMessages.BAD_REQUEST,
                });
                return BadRequest(response);
            }
            catch (ArgumentException ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return BadRequest(response);
            }
            catch (DomainException ex)
            {
                foreach (var message in ex.Messages)
                {
                    response.Messages.Add(message);
                }
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
        }

        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("{id:guid}")]
        public IActionResult Get(Guid id)
        {
            var response = new Response<FirstAidReportModel> { Model = new FirstAidReportModel() };

            try
            {
                var result = _firstAidReportService.FindStatusById(id);

                if (result != null)
                {
                    response.Model = _mapper.Map<FirstAidReportModel>(result);
                    return Ok(response);
                }

                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = Constants.ApplicationMessages.BAD_REQUEST,
                });
                return BadRequest(response);
            }
            catch (ArgumentException ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return BadRequest(response);
            }
            catch (DomainException ex)
            {
                foreach (var message in ex.Messages)
                {
                    response.Messages.Add(message);
                }
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
        }

        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("{pageNo}/{pageSize}/{orderBy}/{orderType}")]
        public IActionResult Get(int pageNo, int pageSize, string orderBy, string orderType)
        {
            var response = new Response<IList<FirstAidReportModel>> { Model = new List<FirstAidReportModel>() };

            try
            {
                var result = _firstAidReportService.FindAll(out int totalRows, pageNo, pageSize, orderBy, orderType);

                if (result != null)
                {
                    response.TotalRows = totalRows;

                    result.ToList().ForEach(d => { response.Model.Add(_mapper.Map<FirstAidReportModel>(d)); });
                    return Ok(response);
                }

                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = Constants.ApplicationMessages.BAD_REQUEST,
                });
                return BadRequest(response);
            }
            catch (ArgumentException ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return BadRequest(response);
            }
            catch (DomainException ex)
            {
                foreach (var message in ex.Messages)
                {
                    response.Messages.Add(message);
                }
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
            catch (Exception ex)
            {
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Error,
                    Value = ex.Message,
                });
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
            }
        }
    }
}
