﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SafetyApp.Core;
using SafetyApp.Core.Infrastructure;
using SafetyApp.Presentation.Shared.Models;
using SafetyApp.Transaction;
using SafetyApp.Transaction.Service.Interface;
using System.Globalization;
using System.Net;

namespace Safety.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class NearMissReportController : ControllerBase
{
    private readonly IMapper _mapper;
    private readonly INearMissReportService _nearMissService;

    public NearMissReportController(
        IMapper mapper,
        INearMissReportService nearMissService)
    {
        _mapper = mapper;
        _nearMissService = nearMissService;
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpPost]
    public IActionResult Post([FromBody] Request<NearMissReportModel> request)
    {
        var response = new Response<NearMissReportModel> { Model = new NearMissReportModel() };

        try
        {
            if (request == null)
            {
                throw new ArgumentException(Constants.ApplicationMessages.EMPTY_REQUEST);
            }

            var data = _mapper.Map<EN_TXN_NearMissReport>(request.Model);
            var result = _nearMissService.CreateReport(data);

            if (result != null)
            {
                response.Model = _mapper.Map<NearMissReportModel>(result);
                response.Messages.Add(new Message
                {
                    MessageType = MessageType.Success,
                    Value = string.Format(CultureInfo.InvariantCulture,
                        Constants.ApplicationMessages.SUCCESS_CREATED,
                        result.IncidentId)
                });
                return Ok(response);
            }

            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = Constants.ApplicationMessages.BAD_REQUEST,
            });
            return BadRequest(response);
        }
        catch (ArgumentException ex)
        {
            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = ex.Message,
            });
            return BadRequest(response);
        }
        catch (DomainException ex)
        {
            foreach (var message in ex.Messages)
            {
                response.Messages.Add(message);
            }
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
        }
        catch (Exception ex)
        {
            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = ex.Message,
            });
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
        }
    }


    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpGet]
    public IActionResult Get()
    {
        var response = new Response<IEnumerable<NearMissReportModel>> { Model = new List<NearMissReportModel>() };

        try
        {
            var result = _nearMissService.GetAllReports();

            if (result != null)
            {
                response.Model = _mapper.Map<IEnumerable<NearMissReportModel>>(result);
                return Ok(response);
            }

            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = Constants.ApplicationMessages.BAD_REQUEST,
            });
            return NotFound(response);
        }
        catch (Exception ex)
        {
            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = ex.Message,
            });
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
        }
    }


    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpGet("{id}")]
    public IActionResult GetById(Guid id)
    {
        var response = new Response<NearMissReportModel> { Model = new NearMissReportModel() };

        try
        {
            var result = _nearMissService.GetReportById(id);

            if (result != null)
            {
                response.Model = _mapper.Map<NearMissReportModel>(result);
                return Ok(response);
            }

            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = Constants.ApplicationMessages.BAD_REQUEST,
            });
            return BadRequest(response);
        }
        catch (ArgumentException ex)
        {
            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = ex.Message,
            });
            return BadRequest(response);
        }
        catch (DomainException ex)
        {
            foreach (var message in ex.Messages)
            {
                response.Messages.Add(message);
            }
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
        }
        catch (Exception ex)
        {
            response.Messages.Add(new Message
            {
                MessageType = MessageType.Error,
                Value = ex.Message,
            });
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), response);
        }
    }
}
