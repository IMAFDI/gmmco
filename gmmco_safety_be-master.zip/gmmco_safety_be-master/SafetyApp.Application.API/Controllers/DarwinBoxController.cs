﻿using Microsoft.AspNetCore.Mvc;
using SafetyApp.Master.Service.Interface;




namespace SafetyApp.Application.API.Controllers
{
    [ApiController]
    [Route("api/darwinbox")]
    public class DarwinBoxController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;


        public DarwinBoxController
            (IEmployeeService employeeService)
        {
            _employeeService = employeeService ?? throw new ArgumentNullException(nameof(employeeService));
        }




        [HttpGet("employees")]
        public async Task<IActionResult> GetAllEmployees(CancellationToken ct)
        {
            var employees = await _employeeService.GetAllEmployeesAsync(ct);
            return Ok(employees);
        }


        [HttpGet("employees/export/excel")]
        public async Task<IActionResult> ExportToExcel(CancellationToken ct)
        {
            var employees = await _employeeService.GetAllEmployeesAsync(ct);
            var excelBytes = _employeeService.ExportToExcel(employees);

            return File(
                excelBytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "Employees.xlsx"
            );
        }
    }
}
