using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SafetyApp.Audit.Data;
using SafetyApp.Core;
using SafetyApp.Data.Audit;
using SafetyApp.Data.Audit.Extensions;
using SafetyApp.Data.Master;
using SafetyApp.Data.Master.Extensions;
using SafetyApp.Data.Transaction;
using SafetyApp.Data.Transaction.Extensions;
using SafetyApp.Master;
using SafetyApp.Master.Data;
using SafetyApp.Presentation.Shared.Injections;
using SafetyApp.Presentation.Shared.MappingProfiles;
using SafetyApp.Transaction.Data;
using Serilog;
using System.Text;

namespace SAFETYAPP.API;

public class Program
{
    private const string CORS_POLICY = "CorsPolicy";

    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        //// Add services to the container.
        //Log.Logger = new LoggerConfiguration()
        //    .MinimumLevel.Information()
        //    .WriteTo.File("Log/SAFETYAPPAPILog.txt", rollingInterval: RollingInterval.Day)
        //    .CreateLogger();
        //builder.Logging.AddSerilog();

        var connectionString = builder.Configuration.GetConnectionString(Constants.ConfigurationKeys.CONNECTION_STRING);

        builder.Services.AddDbContext<AuditDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_AUDIT");
            }));
        builder.Services.AddDbContext<AuditMigrationDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsAssembly(Constants.Common.SAFETYAPP_LOG_MIGRATION_ASSEMBLY);
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_AUDIT");
            }));
        builder.Services.AddDbContext<MasterDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_MASTER");
            }));
        builder.Services.AddDbContext<MasterMigrationDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsAssembly(Constants.Common.SAFETYAPP_LOG_MIGRATION_ASSEMBLY);
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_MASTER");
            }));
        builder.Services.AddDbContext<TransactionDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_TXN");
            }));
        builder.Services.AddDbContext<TransactionMigrationDbContext>(opts =>
            opts.UseNpgsql(connectionString, options =>
            {
                options.MigrationsAssembly(Constants.Common.SAFETYAPP_TRANSACTION_MIGRATION_ASSEMBLY);
                options.MigrationsHistoryTable("__EFMigrationsHistory", "FN_SAFETYAPP_TXN");
            }));

        builder.Services.AddIdentity<EN_MSTR_User, EN_MSTR_Role>(setup =>
        {
            setup.Lockout.MaxFailedAccessAttempts = 3;
        })
            .AddEntityFrameworkStores<MasterDbContext>();
        var jwtSecurityKey = builder.Configuration
            .GetSection(Constants.ConfigurationSections.IDENTITY_CONFIG)
            .GetSection(Constants.ConfigurationKeys.JWT_SECURITY_KEY).Value ?? string.Empty;
        builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = builder.Configuration
                        .GetSection(Constants.ConfigurationSections.IDENTITY_CONFIG)
                        .GetSection(Constants.ConfigurationKeys.JWT_ISSUER).Value,
                    ValidAudience = builder.Configuration
                        .GetSection(Constants.ConfigurationSections.IDENTITY_CONFIG)
                        .GetSection(Constants.ConfigurationKeys.JWT_AUDIENCE).Value,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecurityKey))
                };
            });


        builder.Services.AddApplicationRepositories();
        builder.Services.AddApplicationServices();
        builder.Services.AddCors();
        builder.Services.AddHttpClient();


        builder.Services.AddAutoMapper(am => am.AddProfile<AutoMapperProfile>(), typeof(AutoMapperProfile).Assembly);

        builder.Services.AddControllers().ConfigureApiBehaviorOptions(options =>
        {
            options.SuppressModelStateInvalidFilter = true;
        });


        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();


        var app = builder.Build();


        // Configure the HTTP request pipeline.
        //if (app.Environment.IsDevelopment())
        //{
        app.UseSwagger();
        app.UseSwaggerUI();
        // }

        app.UseHttpsRedirection();

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllers();



        app.MigrateDatabaseAudit(Log.ForContext<Program>());
        app.MigrateDatabaseMaster(Log.ForContext<Program>());
        app.MigrateDatabaseTransaction(Log.ForContext<Program>());

        app.Run();
    }
}
