﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_FirstInFormationReport : EntityBase
    {
        public Guid Id { get; set; }
        public int IncidentTypeId { get; set; }
        public int LocationHeadId { get; set; }
        public int LocationId { get; set; }
        public string Branch { get; set; }
        public string Dept { get; set; }
        public int TotalNumberOfPeopleInjured { get; set; }
        public DateTime AccidentDateTime { get; set; }
        public TimeSpan WorkStartHourAccidentDay { get; set; }
        public string AccidentDescription { get; set; }
        public string InjuredPersonActivityAtAccident { get; set; }
        public bool IsAccidentCausedByMachinery { get; set; }
        public string NameAndPartOfMachinery { get; set; }
        public bool IsMachineMovedByMechanicalPower { get; set; }
        public string NameAndAddressOfWitnesses { get; set; }
        public string NatureExtentLocationOfInjury { get; set; }
        public string TreatmentProviderName { get; set; }
        public string TreatmentProviderAddress { get; set; }
        public bool LossTimeOccurred { get; set; }
        public DateTime? LossTimeStartDate { get; set; }
        public DateTime? LossTimeEndDate { get; set; }
        public string PropertyLossDetails { get; set; }
        public bool IsInjuiredPersonDied { get; set; }
        public DateTime? DeathDateTime { get; set; }
        public DateTime? PostMortemDateTime { get; set; }
        public string PostMortemProviderName { get; set; }
        public string PostMortemProviderAddress { get; set; }
        public string NoPostMortemReason { get; set; }


        public EN_MSTR_IncidentType IncidentType { get; set; }
        public EN_MSTR_Location Location { get; set; }
    }
}
