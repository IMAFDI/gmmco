﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_FRIInjuredPeople : EntityBase
    {
        public Guid FirstInformationReportId { get; set; }
        public int EmployeeId { get; set; }


        public EN_MSTR_Employee Employee { get; set; }
    }
}
