﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_Notifications : EntityBase
    {
        public Guid NotificationId { get; set; }
        public int UserId { get; set; }
        public Guid IncidentId { get; set; }
        public string Message { get; set; }
        public bool IsRead { get; set; }


        public EN_MSTR_User User { get; set; }

    }
}
