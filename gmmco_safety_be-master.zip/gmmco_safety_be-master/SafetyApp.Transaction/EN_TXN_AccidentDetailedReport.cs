﻿
using SafetyApp.Core;

namespace SafetyApp.Transaction;

public class EN_TXN_AccidentDetailedReport : EntityBase
{
    public Guid Id { get; set; }
    public Guid FirstInFormationReportId { get; set; }
    public string ChronologyOfEvents { get; set; }


    public EN_TXN_FirstInFormationReport FirstInFormationReport { get; set; }

}