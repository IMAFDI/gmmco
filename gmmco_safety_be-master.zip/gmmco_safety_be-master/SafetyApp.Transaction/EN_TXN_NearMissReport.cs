﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_NearMissReport : EntityBase
    {
        public Guid ReportId { get; set; }
        public Guid IncidentId { get; set; }
        public string PotentialHazards { get; set; }
        public string PreventiveActions { get; set; }
        public int LocationId { get; set; }
        public int WorkstationId { get; set; }
        public bool UnsafeAct { get; set; }
        public bool UnsafeCondition { get; set; }
        public string TempSolution { get; set; }
        public string PermanentSolution { get; set; }
        public DateOnly? DateOfCompleted { get; set; }
        public int VerifiedBy { get; set; }

        public EN_MSTR_Location Location { get; set; }
        public EN_MSTR_Workstation Workstation { get; set; }
    }
}
