﻿using SafetyApp.Core;

namespace SafetyApp.Transaction
{
    public class EN_TXN_IncidentAttachment : EntityBase
    {
        public Guid AttachmentId { get; set; }
        public Guid IncidentId { get; set; }
        public Guid AccidentDetailedReportId { get; set; }
        public string FilePath { get; set; }
        public DateTime UploadedAt { get; set; }


        public EN_TXN_AccidentDetailedReport AccidentDetailedReport { get; set; }
    }
}
