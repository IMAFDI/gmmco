﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_PermitToWork : EntityBase
    {
        public int PermitId { get; set; }
        public int PermitTypeId { get; set; }
        public string FormatNo { get; set; }
        public int IssueNo { get; set; }
        public DateTime IssueDate { get; set; }
        public int? AmendmentNo { get; set; }
        public DateOnly? AmendmentDate { get; set; }
        public DateTime DateOfPermit { get; set; }
        public TimeSpan TimeOfPermit { get; set; }
        public string PermitNo { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public string Plant { get; set; }
        public string AreaLocation { get; set; }
        public string EquipmentMachines { get; set; }
        public string ContractorName { get; set; }
        public int ManpowerCount { get; set; }
        public string SpecificWorkActivity { get; set; }
        public string DescriptionActivity { get; set; }
        public string ChecklistJson { get; set; }
        public string InsuranceNumber { get; set; }
        public string AuthorizedBy { get; set; }
        public DateTime? ExtensionFrom { get; set; }
        public DateTime? ExtensionTo { get; set; }
        public string ExtensionSignBy { get; set; }
        public DateTime? PermitClosedOn { get; set; }
        public string ClosedBy { get; set; }


        public EN_MSTR_PermitType PermitType { get; set; }

    }
}
