﻿using SafetyApp.Core;

namespace SafetyApp.Transaction
{
    public class EN_TXN_Incidents : EntityBase
    {
        public Guid IncidentId { get; set; }
        public string InjuryType { get; set; }
        public string TreatmentProvided { get; set; }
        public string Description { get; set; }
        public string RootCauseForTheIncident { get; set; }
        public int ReportedBy { get; set; }
        public DateTime ReportedDate { get; set; }
        public int Status { get; set; }
        public string Remarks { get; set; }
        public int? ClosedBy { get; set; }
        public DateTime? ClosedAt { get; set; }
        public int CreatedId { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? UpdatedId { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }
        public DateTime? DeletedAt { get; set; }
        public int? DeletedBy { get; set; }
        public string RecordSourceName { get; set; }
    }
}
