﻿using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Transaction.Repositories
{
    public interface IIncidentRepository : IGenericRepository<Guid, EN_TXN_Incidents>
    {
    }
}
