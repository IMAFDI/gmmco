﻿using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Transaction.Repositories;

public interface IFirstAidReportRepository : IGenericRepository<Guid, EN_TXN_FirstAidReport>
{
}
