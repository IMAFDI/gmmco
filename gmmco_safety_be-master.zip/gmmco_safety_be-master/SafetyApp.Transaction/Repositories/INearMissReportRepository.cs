﻿using SafetyApp.Core.Data.Interface;

namespace SafetyApp.Transaction.Repositories
{
    public interface INearMissReportRepository : IGenericRepository<Guid, EN_TXN_NearMissReport> { }
}
