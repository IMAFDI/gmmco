﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_FirstAidReport : EntityBase
    {
        public Guid ReportId { get; set; }
        public Guid IncidentId { get; set; }
        public string ItemUsed { get; set; }
        public float ExperienceInGmmco { get; set; }
        public int ReportingManager { get; set; }


        public EN_MSTR_IncidentType IncidentType { get; set; }
        public EN_TXN_Incidents Incident { get; set; }
    }
}
