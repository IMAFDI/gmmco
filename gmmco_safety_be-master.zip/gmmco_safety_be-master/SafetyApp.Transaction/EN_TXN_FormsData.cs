﻿using SafetyApp.Core;
using SafetyApp.Master;

namespace SafetyApp.Transaction
{
    public class EN_TXN_FormsData : EntityBase
    {
        public Guid Id { get; set; }
        public int FormTypeId { get; set; }
        public string FormData { get; set; }


        public EN_MSTR_FormType FormType { get; set; }
    }
}
